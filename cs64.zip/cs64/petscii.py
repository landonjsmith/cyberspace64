from __future__ import annotations

CLR = b"\x93"
HOME = b"\x13"
RVS_ON = b"\x12"
RVS_OFF = b"\x92"
CRSR_DOWN = b"\x11"
CRSR_UP = b"\x91"
CRSR_LEFT = b"\x9d"
CRSR_RIGHT = b"\x1d"


DEL = b"\x14"
RETURN = b"\x0d"


LOWERCASE_CHARSET = b"\x0e"
UPPERCASE_CHARSET = b"\x8e"

COLOR = {
    "black": b"\x90", "white": b"\x05", "red": b"\x1c", "cyan": b"\x9f",
    "purple": b"\x9c", "green": b"\x1e", "blue": b"\x1f", "yellow": b"\x9e",
    "orange": b"\x81", "brown": b"\x95", "light_red": b"\x96",
    "dark_grey": b"\x97", "grey": b"\x98", "light_green": b"\x99",
    "light_blue": b"\x9a", "light_grey": b"\x9b", "purple2": b"\x9c",
}

SCREEN_WIDTH = 40


PETSCII_FSLASH = 0xCE
PETSCII_BSLASH = 0xCD


PETSCII_UPARROW_EXPERIMENTAL_RULED_OUT = 0xDE


STYLIZED_TEXT_SUBSTITUTIONS = {
    "ᑕ¥βєяรקค¢є": "CYBERSPACE",
}


def _apply_stylized_substitutions(text: str) -> str:
    for stylized, plain in STYLIZED_TEXT_SUBSTITUTIONS.items():
        text = text.replace(stylized, plain)
    return text


def encode(text: str, literal_slashes: bool = False) -> bytes:
    text = _apply_stylized_substitutions(text)
    out = bytearray()
    for ch in text.upper():
        code = ord(ch)
        if ch == "\n":
            out += RETURN
        elif ch == "_":


            out.append(0xA4)
        elif ch == "\\":
            out.append(PETSCII_BSLASH)
        elif ch == "/":
            out.append(code if literal_slashes else PETSCII_FSLASH)
        elif ch == "^":
            out.append(code)
        elif 32 <= code <= 90:

            out.append(code)
        elif ch in "!\"#$%&'()*+,-.:;<=>?@[]":
            out.append(code)

    return bytes(out)


def petscii_safe(text: str) -> str:
    text = _apply_stylized_substitutions(text)
    out = []
    for ch in text.upper():
        code = ord(ch)
        if ch in ("_", "\\", "/", "^"):
            out.append(ch)
        elif 32 <= code <= 90:
            out.append(ch)
        elif ch in "!\"#$%&'()*+,-.:;<=>?@[]":
            out.append(ch)

    return "".join(out)


def wrap(text: str, width: int = SCREEN_WIDTH) -> list[str]:
    words = text.split(" ")
    lines: list[str] = []
    current = ""
    for word in words:
        while len(word) > width:

            if current:
                lines.append(current)
                current = ""
            lines.append(word[:width])
            word = word[width:]
        candidate = (current + " " + word).strip() if current else word
        if len(candidate) > width:
            lines.append(current)
            current = word
        else:
            current = candidate
    if current:
        lines.append(current)
    return lines or [""]


def line(text: str = "", width: int = SCREEN_WIDTH) -> bytes:
    return encode(text[:width]) + RETURN


def centered(text: str, width: int = SCREEN_WIDTH, literal_slashes: bool = False) -> bytes:
    text = text[:width]
    pad = max(0, (width - len(text)) // 2)
    return encode(" " * pad + text, literal_slashes=literal_slashes) + RETURN


def rule(width: int = SCREEN_WIDTH) -> bytes:
    return encode("-" * width) + RETURN


NAME_PALETTE = [
    "white", "cyan", "yellow", "light_green", "light_red",
    "orange", "purple", "light_blue", "light_grey", "green",
]


def color_for(name: str) -> bytes:
    idx = sum(ord(c) for c in name.upper()) % len(NAME_PALETTE)
    return COLOR[NAME_PALETTE[idx]]


def colored(text: str, color_name: str) -> bytes:
    return COLOR[color_name] + encode(text) + COLOR["white"]


def segment_line(segments: list[tuple[bytes | None, str]], width: int = SCREEN_WIDTH) -> bytes:
    out = bytearray()
    remaining = width
    for color, text in segments:
        if remaining <= 0:
            break
        text = text[:remaining]
        remaining -= len(text)
        if color:
            out += color
        out += encode(text)
    out += COLOR["white"] + RETURN
    return bytes(out)


def local_timestamp(ts_millis: int) -> str:
    import time as _time
    return _time.strftime("%H:%M", _time.localtime(ts_millis / 1000))


def ellipsize(text: str, width: int) -> str:
    if len(text) <= width:
        return text
    if width <= 3:
        return text[:width]
    return text[:width - 3] + "..."


def header_bar(text: str, width: int = SCREEN_WIDTH) -> bytes:
    text = ellipsize(text, width)
    pad_total = width - len(text)
    left = pad_total // 2
    right = pad_total - left
    return (
        RVS_ON
        + encode(" " * left + text + " " * right)
        + RVS_OFF
        + RETURN
    )


def box_top(width: int = SCREEN_WIDTH) -> bytes:
    return encode("." + "-" * (width - 2) + ".") + RETURN


def box_bottom(width: int = SCREEN_WIDTH) -> bytes:
    return encode("'" + "-" * (width - 2) + "'") + RETURN


def box_divider(width: int = SCREEN_WIDTH) -> bytes:
    return encode(":" + "." * (width - 2) + ":") + RETURN


def box_row(text: str, width: int = SCREEN_WIDTH, color: bytes | None = None) -> bytes:
    inner = width - 4
    text = text[:inner]
    body = encode(text + " " * (inner - len(text)))
    if color:
        body = color + body + COLOR["white"]
    return encode(": ") + body + encode(" :") + RETURN


def input_prompt(label: str = "TYPE", width: int = SCREEN_WIDTH,
                  literal_slashes: bool = False) -> bytes:
    return (
        COLOR["yellow"]
        + RVS_ON
        + encode(f" {label} ", literal_slashes=literal_slashes)
        + RVS_OFF
        + COLOR["yellow"]
        + encode("> ")
        + COLOR["white"]
    )


def menu_item(key: str, label: str, hint: str | None = None,
              width: int = SCREEN_WIDTH, hint_color: bytes | None = None) -> bytes:
    inner = width - 4
    key_tab = f" {key} "
    out = encode(": ") + RVS_ON + COLOR["yellow"] + encode(key_tab) + RVS_OFF + COLOR["white"]
    used = len(key_tab)
    remaining = inner - used - 1
    label = label[:remaining]
    if hint:
        gap = remaining - len(label)
        hint_fits = gap - 1 >= len(hint) + 1
        if hint_fits:
            pad = gap - len(hint) - 1
            out += (
                encode(f" {label}" + " " * pad + " ")
                + (hint_color or COLOR["white"]) + encode(hint) + COLOR["white"]
            )
            used += 1 + len(label) + pad + 1 + len(hint)
        else:
            out += encode(f" {label}".ljust(remaining))
            used += 1 + remaining
    else:
        out += encode(f" {label}".ljust(remaining))
        used += 1 + remaining
    pad_end = max(0, inner - used)
    out += encode(" " * pad_end + " :") + RETURN
    return out


def menu_item_pair(key1: str, label1: str, key2: str, label2: str,
                    width: int = SCREEN_WIDTH, gap: int = 2,
                    label1_color: bytes | None = None,
                    label2_color: bytes | None = None) -> bytes:
    inner = width - 4
    col = (inner - gap) // 2

    def one(key: str, label: str, color: bytes | None) -> bytes:
        key_tab = f" {key} "
        out = RVS_ON + COLOR["yellow"] + encode(key_tab) + RVS_OFF
        budget = max(0, col - len(key_tab))
        if budget <= 0:
            return out
        label = label[:budget - 1]
        segment = f" {label}".ljust(budget)
        out += (color or COLOR["white"]) + encode(segment)
        return out

    left = one(key1, label1, label1_color)
    right = one(key2, label2, label2_color)
    used_total = col + gap + col
    pad_end = max(0, inner - used_total)
    return (
        encode(": ") + left + encode(" " * gap) + right
        + COLOR["white"] + encode(" " * pad_end + " :") + RETURN
    )


def status_line(text: str, width: int = SCREEN_WIDTH) -> bytes:
    return COLOR["white"] + line(text, width) + COLOR["white"]


RAINBOW_PALETTE = [
    "red", "orange", "yellow", "light_green", "cyan", "light_blue", "purple",
]


def rainbow_color(index: int) -> bytes:
    return COLOR[RAINBOW_PALETTE[index % len(RAINBOW_PALETTE)]]


def spinner_frame(tick: int) -> bytes:
    return b"\xc0\xcd\xdd\xce"[tick % 4:tick % 4 + 1]


GLOBE_ART = [
    "...######...",
    "..#.#..#.#..",
    ".#.#....#.#.",
    "#..#....#..#",
    "############",
    "#..#....#..#",
    "#..#....#..#",
    "############",
    "#..#....#..#",
    ".#.#....#.#.",
    "..#.#..#.#..",
    "...######...",
]


def globe_lines(width: int = SCREEN_WIDTH) -> list[bytes]:
    pad = max(0, (width - len(GLOBE_ART[0])) // 2)
    lines = []
    for row in GLOBE_ART:
        out = bytearray(encode(" " * pad))
        on = False
        for ch in row:
            want_on = ch == "#"
            if want_on and not on:
                out += RVS_ON
                on = True
            elif not want_on and on:
                out += RVS_OFF
                on = False
            out += encode(" ")
        if on:
            out += RVS_OFF
        lines.append(bytes(out) + RETURN)
    return lines
