from __future__ import annotations

import argparse
import asyncio
import contextlib
import json
import os
import re
import time
from datetime import datetime

import aiohttp

import petscii as p
from cyberspace_client import CyberSpaceClient, CyberSpaceError

CLIENT_VERSION = "BETA 1.0"

POLL_INTERVAL_SEC = 3.0


LIST_POLL_INTERVAL_SEC = 3.0


WHO_POLL_INTERVAL_SEC = 3.0


URL_RE = re.compile(r"https?://\S+", re.IGNORECASE)


CS_IMAGE_EMBED_RE = re.compile(r"!\[[^\]]*\](?:\([^)]*\))?")


MD_LINK_RE = re.compile(r"\[([^\]]*)\]\(([^)]*)\)")


MD_CODE_FENCE_RE = re.compile(r"^```.*$", re.MULTILINE)


MD_INLINE_CODE_RE = re.compile(r"`([^`]*)`")


MD_HEADING_RE = re.compile(r"^#{1,6}[ \t]+", re.MULTILINE)


MD_EMPHASIS_RES = [re.compile(p) for p in (
    r"\*\*\*(.+?)\*\*\*", r"___(.+?)___",
    r"\*\*(.+?)\*\*", r"__(.+?)__",
    r"\*(.+?)\*", r"_(.+?)_",
)]


def _strip_markdown(text: str) -> str:
    if not text:
        return text
    text = MD_LINK_RE.sub("[WEB LINK]", text)
    text = MD_CODE_FENCE_RE.sub("", text)
    text = MD_INLINE_CODE_RE.sub(r"\1", text)
    text = MD_HEADING_RE.sub("", text)
    for pattern in MD_EMPHASIS_RES:
        text = pattern.sub(r"\1", text)
    return text


def _collapse_ascii_art_blocks(text: str) -> str:
    lines = text.splitlines()
    out_lines: list[str] = []
    i = 0
    while i < len(lines):
        def _is_art_line(ln: str) -> bool:
            return bool(ln.strip()) and not p.petscii_safe(ln).strip()

        if _is_art_line(lines[i]):
            j = i
            while j < len(lines) and _is_art_line(lines[j]):
                j += 1
            if j - i >= 2:
                out_lines.append("[ASCII ART]")
                i = j
                continue
        out_lines.append(lines[i])
        i += 1
    return "\n".join(out_lines)


DEFAULT_IDLE_AFTER_MS = 600_000


CASE_TOGGLE_BYTE = 0x5E


CASE_MODE_COLORS = {True: p.COLOR["white"], False: p.COLOR["light_green"]}


REMEMBERED_LOGINS_PATH = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "remembered_logins.json"
)


def _load_remembered_state() -> dict:
    try:
        with open(REMEMBERED_LOGINS_PATH, "r") as f:
            data = json.load(f)
    except FileNotFoundError:
        return {"logins": {}, "last": None}
    except (json.JSONDecodeError, OSError) as e:
        print(f"[!] couldn't read {REMEMBERED_LOGINS_PATH}: {e!r} -- "
              f"treating as no remembered logins")
        return {"logins": {}, "last": None}

    if not isinstance(data, dict):
        return {"logins": {}, "last": None}
    if isinstance(data.get("logins"), dict):
        return {"logins": data["logins"], "last": data.get("last")}
    return {"logins": data, "last": None}


def _save_remembered_state(state: dict) -> None:
    try:
        with open(REMEMBERED_LOGINS_PATH, "w") as f:
            json.dump(state, f)
    except OSError as e:
        print(f"[!] couldn't write {REMEMBERED_LOGINS_PATH}: {e!r} -- "
              f"\"remember me\" won't persist this time")


def _remember_login(email: str, refresh_token: str) -> None:
    state = _load_remembered_state()
    key = email.strip().lower()
    state["logins"][key] = refresh_token
    state["last"] = key
    _save_remembered_state(state)


def _forget_login(email: str) -> None:
    state = _load_remembered_state()
    key = email.strip().lower()
    removed = state["logins"].pop(key, None) is not None
    if state.get("last") == key:
        state["last"] = None
    if removed:
        _save_remembered_state(state)


def _get_remembered_refresh_token(email: str) -> str | None:
    if not email:
        return None
    return _load_remembered_state()["logins"].get(email.strip().lower())


def _get_last_remembered_email() -> str | None:
    return _load_remembered_state().get("last")


def _mark_last_remembered(email: str) -> None:
    state = _load_remembered_state()
    key = email.strip().lower()
    if key in state["logins"] and state.get("last") != key:
        state["last"] = key
        _save_remembered_state(state)


class TelnetConn:

    def __init__(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
        self.reader = reader
        self.writer = writer


        self.busy_event = asyncio.Event()
        self.busy_event.set()


        self._skip_next_lf = False

    async def write(self, data: bytes):
        self.writer.write(data)
        await self.writer.drain()

    async def write_gated(self, data: bytes):
        await self.busy_event.wait()
        await self.write(data)

    async def write_line_gated(self, text: str = ""):
        await self.write_gated(p.line(text))

    async def write_line(self, text: str = ""):
        await self.write(p.line(text))

    async def clear(self):
        await self.write(p.CLR)

    async def read_key(self) -> int:
        while True:
            b = await self.reader.read(1)
            if not b:
                raise ConnectionError("client disconnected")
            byte = b[0]
            if byte == 0xFF:
                await self.reader.read(2)
                continue
            if self._skip_next_lf:
                self._skip_next_lf = False
                if byte == 0x0A:
                    continue
            return byte

    async def read_line(self, echo: bool = True, mask: bool = False,
                         allow_case_toggle: bool = False,
                         charset: bytes = None) -> str:


        await self.write(charset if charset is not None else p.UPPERCASE_CHARSET)
        buf = bytearray()
        lowercase_mode = True
        try:
            while True:
                b = await self.reader.read(1)
                if not b:
                    raise ConnectionError("client disconnected")
                byte = b[0]
                if byte == 0xFF:
                    await self.reader.read(2)
                    continue
                if self._skip_next_lf:
                    self._skip_next_lf = False
                    if byte == 0x0A:
                        continue
                if allow_case_toggle and byte == CASE_TOGGLE_BYTE:
                    lowercase_mode = not lowercase_mode


                    await self.write(b"\x07" + CASE_MODE_COLORS[lowercase_mode])
                    continue
                if byte == 0x0D:
                    self._skip_next_lf = True
                    if echo:
                        payload = p.RETURN
                        if allow_case_toggle:
                            payload = p.COLOR["white"] + payload
                        await self.write(payload)
                    return bytes(buf).decode("ascii", errors="replace")
                if byte == 0x0A:
                    continue
                if byte in (0x14, 0x7F, 0x08):
                    if buf:
                        buf.pop()
                        if echo:
                            await self.write(b"\x14")
                    if not buf:
                        self.busy_event.set()
                    continue


                store_byte = byte
                if allow_case_toggle and lowercase_mode and 65 <= byte <= 90:
                    store_byte = byte + 32
                buf.append(store_byte)
                self.busy_event.clear()
                if echo:


                    payload = p.encode(chr(byte), literal_slashes=True) if not mask else b"*"
                    if allow_case_toggle:
                        payload = CASE_MODE_COLORS[lowercase_mode] + payload
                    await self.write(payload)
        finally:
            self.busy_event.set()


SPINNER_INTERVAL_SEC = 0.2


NEW_MESSAGE_FLASH_SEC = 0.35


@contextlib.asynccontextmanager
async def loading(conn: TelnetConn, label: str = "LOADING"):
    text = f"{label}..."
    await conn.write(p.COLOR["white"] + p.encode(text) + p.COLOR["white"])
    try:
        yield
    finally:


        erase_len = len(text)
        await conn.write(p.CRSR_LEFT * erase_len)
        await conn.write(p.encode(" " * erase_len))
        await conn.write(p.CRSR_LEFT * erase_len)
        await conn.write(p.COLOR["white"])


async def show_banner(conn: TelnetConn):
    await conn.clear()
    await conn.write(p.COLOR["yellow"])
    for row in p.globe_lines():
        await conn.write(row)
    await conn.write_line()
    await conn.write(p.COLOR["white"])
    await conn.write(p.centered("C Y B E R S P A C E / 6 4", literal_slashes=True))
    await conn.write_line()
    await conn.write(p.COLOR["yellow"])
    await conn.write(p.centered("A GATEWAY FOR CYBERSPACE.ONLINE"))
    await conn.write(p.centered(CLIENT_VERSION))
    await conn.write(p.COLOR["white"])
    await conn.write_line()


async def show_credits(conn: TelnetConn):
    await conn.clear()
    await conn.write(p.COLOR["yellow"])
    await conn.write(p.header_bar("CREDITS"))
    await conn.write(p.COLOR["white"])
    await conn.write_line()
    await conn.write_line("C Y B E R S P A C E / 6 4")
    await conn.write_line(CLIENT_VERSION)
    await conn.write_line()
    await conn.write_line("A TELNET/PETSCII BRIDGE FOR")
    await conn.write_line("CYBERSPACE.ONLINE")
    await conn.write_line()
    await conn.write_line("PROGRAMMED BY LANDON J. SMITH")
    await conn.write_line("(C) 2026 LANDON J. SMITH")
    await conn.write_line("ALL RIGHTS RESERVED")
    await conn.write_line()
    for wline in p.wrap("CYBERSPACE.ONLINE, THE CYBERSPACE API, AND "
                         "ALL OTHER CYBERSPACE-RELATED MATERIAL ARE "
                         "COPYRIGHT OF @UNREMARKABLEGARDEN."):
        await conn.write_line(wline)
    await conn.write_line()
    await conn.write(p.status_line("PRESS ANY KEY TO GO BACK."))
    await conn.write(p.COLOR["white"])
    await conn.read_key()


AUTO_LOGIN_GRACE_SEC = 3.0


async def _attempt_remembered_login(conn: TelnetConn, client: CyberSpaceClient,
                                     email: str, refresh_token: str) -> dict | None:
    try:
        async with loading(conn, "SIGNING IN"):
            client.refresh_token = refresh_token
            await client.refresh()
            me = await client.me()
        print(f"[+] {email!r} auto-signed in via remembered login")
        _mark_last_remembered(email)
        await conn.write_line()
        await conn.write(p.COLOR["light_green"])
        await conn.write_line(f"WELCOME BACK, {me.get('username','').upper()}!")
        await conn.write(p.COLOR["white"])
        await asyncio.sleep(1)
        return me
    except (ConnectionError, asyncio.IncompleteReadError):
        raise
    except CyberSpaceError as e:
        print(f"[!] remembered login for {email!r} failed: "
              f"{e.code}: {e.message} (HTTP {e.status})")
        _forget_login(email)
        client.refresh_token = None
        await conn.write(p.COLOR["light_red"])
        await conn.write_line("YOUR SAVED LOGIN STOPPED WORKING:")
        for wline in p.wrap(e.message.upper()):
            await conn.write_line(wline)
        await conn.write_line("PLEASE SIGN IN AGAIN.")
        await conn.write(p.COLOR["white"])
        await conn.write_line()
        return None
    except Exception as e:
        print(f"[!] remembered login for {email!r} failed ({e!r}) -- "
              f"falling back to password")
        _forget_login(email)
        client.refresh_token = None
        await conn.write(p.COLOR["light_red"])
        await conn.write_line("YOUR SAVED LOGIN STOPPED WORKING --")
        await conn.write_line("PLEASE SIGN IN AGAIN.")
        await conn.write(p.COLOR["white"])
        await conn.write_line()
        return None


async def _try_auto_login(conn: TelnetConn, client: CyberSpaceClient) -> dict | None:
    email = _get_last_remembered_email()
    token = _get_remembered_refresh_token(email) if email else None
    if not email or not token:
        return None

    await conn.write(p.COLOR["yellow"])
    await conn.write(p.header_bar("SIGN IN"))
    await conn.write(p.COLOR["white"])
    await conn.write_line()
    await conn.write(p.status_line("SIGNING YOU IN..."))
    await conn.write(p.status_line("PRESS ANY KEY FOR A DIFFERENT LOGIN."))
    await conn.write_line()

    key_task = asyncio.create_task(conn.read_key())
    grace_task = asyncio.create_task(asyncio.sleep(AUTO_LOGIN_GRACE_SEC))
    done, _ = await asyncio.wait({key_task, grace_task}, return_when=asyncio.FIRST_COMPLETED)

    if key_task in done:


        grace_task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await grace_task
        return None

    key_task.cancel()
    with contextlib.suppress(asyncio.CancelledError):
        await key_task

    return await _attempt_remembered_login(conn, client, email, token)


async def do_login(conn: TelnetConn, client: CyberSpaceClient) -> dict:
    auto = await _try_auto_login(conn, client)
    if auto is not None:
        return auto

    first_try = True
    while True:
        await conn.write(p.COLOR["yellow"])
        await conn.write(p.header_bar("SIGN IN"))
        await conn.write(p.COLOR["white"])
        await conn.write_line()
        if first_try:
            await conn.write(p.status_line("ENTER YOUR CYBERSPACE ACCOUNT BELOW."))
            await conn.write(p.status_line("UP ARROW=CASE TOGGLE (WHITE=LO GRN=UP)."))
            await conn.write_line()
            first_try = False
        await conn.write(p.COLOR["yellow"] + p.encode("EMAIL: ") + p.COLOR["white"])
        email = (await conn.read_line(allow_case_toggle=True,
                                       charset=p.LOWERCASE_CHARSET)).strip()


        remembered_token = _get_remembered_refresh_token(email)
        if remembered_token:
            me = await _attempt_remembered_login(conn, client, email, remembered_token)
            if me is not None:
                return me

        await conn.write(p.COLOR["yellow"] + p.encode("PASSWORD: ") + p.COLOR["white"])
        password = (await conn.read_line(mask=True, allow_case_toggle=True,
                                          charset=p.LOWERCASE_CHARSET)).strip()
        await conn.write_line()
        await conn.write_line()
        await conn.write(p.COLOR["white"])
        try:
            async with loading(conn, "SIGNING IN"):
                await client.login(email, password)
                me = await client.me()
            await conn.write_line()
            await conn.write(p.COLOR["light_green"])
            await conn.write_line(f"WELCOME BACK, {me.get('username','').upper()}!")
            await conn.write(p.COLOR["white"])
            await conn.write_line()

            await conn.write(p.COLOR["yellow"])
            await conn.write(p.status_line("REMEMBER THIS LOGIN ON THIS BRIDGE?"))
            await conn.write(p.COLOR["white"])
            await conn.write(p.input_prompt("Y/N", literal_slashes=True))
            answer = (await conn.read_line(allow_case_toggle=True,
                                            charset=p.LOWERCASE_CHARSET)).strip().upper()
            if answer.startswith("Y") and client.refresh_token:
                _remember_login(email, client.refresh_token)
                print(f"[+] remembered login saved for {email!r} -> {REMEMBERED_LOGINS_PATH}")
                await conn.write(p.COLOR["light_green"])
                await conn.write_line("INFORMATION SAVED!")
                await conn.write(p.COLOR["white"])

            await asyncio.sleep(1)
            return me
        except CyberSpaceError as e:
            await conn.write(p.COLOR["light_red"])
            if e.code == "EMAIL_NOT_VERIFIED":
                await conn.write_line("ALMOST THERE -- PLEASE VERIFY YOUR")
                await conn.write_line("EMAIL FIRST, THEN TRY AGAIN.")
            else:
                await conn.write_line("HMM, THAT DIDN'T WORK:")
                await conn.write_line(e.message.upper())
            await conn.write(p.COLOR["white"])
            await conn.write_line()


async def _check_genuinely_new_notifs(client: CyberSpaceClient,
                                       seen_notif_ids: set[str]) -> bool:
    try:
        result = await client.notifications_list(limit=50, read=False)
    except CyberSpaceError:
        return False
    unread_items = result.get("data") or []
    return any(n.get("id") not in seen_notif_ids for n in unread_items)


async def _check_genuinely_new_cmail(client: CyberSpaceClient,
                                      seen_cmail_unread_counts: dict[str, int]) -> bool:
    try:
        conversations = await client.cmail_list()
    except CyberSpaceError:
        return False
    return any(
        (c.get("unreadCount") or 0) > seen_cmail_unread_counts.get(c.get("conversationId"), 0)
        for c in (conversations or [])
        if c.get("conversationId")
    )


async def _draw_main_menu(conn: TelnetConn, me: dict, genuinely_new: bool,
                           cmail_new: bool = False):
    await conn.clear()
    await conn.write(p.COLOR["yellow"])
    await conn.write(p.header_bar(f"MAIN MENU -- {me.get('username','').upper()}"))
    await conn.write(p.box_top())
    await conn.write(p.box_row("WHAT WOULD YOU LIKE TO DO?", color=p.COLOR["white"]))
    await conn.write(p.box_divider())
    notif_color = p.COLOR["light_red"] if genuinely_new else None
    cmail_color = p.COLOR["light_red"] if cmail_new else None


    await conn.write(p.menu_item_pair("C", "CHAT ROOMS", "F", "FEED VIEWER"))
    await conn.write(p.menu_item_pair("W", "WRITE POST", "M", "C-MAIL",
                                       label2_color=cmail_color))
    await conn.write(p.menu_item_pair("N", "NOTIFICATIONS", "U", "USER LOOKUP",
                                       label1_color=notif_color))
    await conn.write(p.menu_item_pair("R", "SAVED LOGIN", "Q", "QUIT"))
    await conn.write(p.menu_item("I", "CREDITS"))
    await conn.write(p.box_bottom())
    await conn.write(p.COLOR["white"])
    await conn.write(p.input_prompt("PICK"))


async def main_menu(conn: TelnetConn, client: CyberSpaceClient, me: dict,
                     seen_notif_ids: set[str], seen_cmail_unread_counts: dict[str, int]) -> str:
    await conn.clear()
    async with loading(conn):
        genuinely_new = await _check_genuinely_new_notifs(client, seen_notif_ids)
        cmail_new = await _check_genuinely_new_cmail(client, seen_cmail_unread_counts)
    await _draw_main_menu(conn, me, genuinely_new, cmail_new)

    badge_changed_event = asyncio.Event()
    stop_poll = asyncio.Event()

    async def poller():
        nonlocal genuinely_new, cmail_new
        while not stop_poll.is_set():
            try:
                await client.ensure_fresh_token()
                new_notif_state = await _check_genuinely_new_notifs(client, seen_notif_ids)
                new_cmail_state = await _check_genuinely_new_cmail(client, seen_cmail_unread_counts)
                if new_notif_state != genuinely_new or new_cmail_state != cmail_new:
                    genuinely_new, cmail_new = new_notif_state, new_cmail_state
                    badge_changed_event.set()
            except CyberSpaceError:
                pass
            except Exception as e:


                print(f"[!] main menu poller: {e!r} -- will retry")
            try:
                await asyncio.wait_for(stop_poll.wait(), timeout=LIST_POLL_INTERVAL_SEC)
            except asyncio.TimeoutError:
                pass

    poll_task = asyncio.create_task(poller())
    try:
        line_task = asyncio.create_task(conn.read_line(allow_case_toggle=True))
        try:
            while not line_task.done():
                change_task = asyncio.create_task(badge_changed_event.wait())
                done, _ = await asyncio.wait({line_task, change_task},
                                              return_when=asyncio.FIRST_COMPLETED)
                if change_task not in done:
                    change_task.cancel()
                    with contextlib.suppress(asyncio.CancelledError):
                        await change_task
                    continue
                badge_changed_event.clear()
                await conn.busy_event.wait()
                await _draw_main_menu(conn, me, genuinely_new, cmail_new)
        finally:
            if not line_task.done():
                line_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await line_task
        choice = line_task.result().strip().upper()
    finally:
        stop_poll.set()
        poll_task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await poll_task
    return choice


MAX_ROOM_ROWS = 17  # one under the tightest-fit 18 -- extra row of headroom on this
                     # screen specifically, on top of the loading()-before-clear() fix


async def show_room_selector(conn: TelnetConn, client: CyberSpaceClient) -> tuple[str, str] | None:
    await conn.clear()
    try:
        async with loading(conn):
            rooms = await client.circ_list_rooms()
    except CyberSpaceError as e:
        await conn.clear()
        await conn.write(p.COLOR["yellow"])
        await conn.write(p.header_bar("CHAT ROOMS"))
        await conn.write(p.COLOR["light_red"])
        await conn.write_line(f"COULDN'T LOAD ROOMS: {e.message.upper()}")
        await conn.write(p.COLOR["white"])
        await conn.write_line()
        await conn.write(p.status_line("PRESS ANY KEY TO GO BACK."))
        await conn.read_key()
        return None

    if not rooms:
        await conn.clear()
        await conn.write(p.COLOR["yellow"])
        await conn.write(p.header_bar("CHAT ROOMS"))
        await conn.write(p.COLOR["white"])
        await conn.write(p.status_line("NO ROOMS ARE AVAILABLE RIGHT NOW."))
        await conn.write_line()
        await conn.write(p.status_line("PRESS ANY KEY TO GO BACK."))
        await conn.read_key()
        return None

    page_index = 0
    page_count = (len(rooms) - 1) // MAX_ROOM_ROWS + 1
    while True:
        page_start = page_index * MAX_ROOM_ROWS
        page_rooms = rooms[page_start:page_start + MAX_ROOM_ROWS]

        await conn.clear()
        for i, room in enumerate(page_rooms, start=1):
            name = room.get("name") or room.get("slug") or room.get("id") or "?"
            online = room.get("onlineCount") or 0
            await conn.write(p.COLOR["yellow"])
            await conn.write(p.encode(f"{i:>2} "))
            await conn.write(p.COLOR["white"])
            await conn.write(p.encode(f"{name:<27}"[:27]))
            await conn.write(p.COLOR["white"])
            await conn.write_line(f"{online} ON")
        await conn.write(p.COLOR["white"])
        await conn.write(p.rule())
        await conn.write(p.COLOR["yellow"])
        header = "CHAT ROOMS" if page_count == 1 else f"CHAT ROOMS -- PAGE {page_index + 1}/{page_count}"
        await conn.write(p.header_bar(header))
        await conn.write(p.COLOR["white"])
        hint = "PICK A ROOM BY NUMBER, B = BACK."
        if page_count > 1:
            hint = "PICK A ROOM #. N=NEXT P=PREV B=BACK."
        await conn.write(p.status_line(hint))
        await conn.write(p.COLOR["white"])
        await conn.write(p.rule())
        await conn.write(p.COLOR["white"])
        await conn.write(p.input_prompt("ROOM #"))
        choice = (await conn.read_line(allow_case_toggle=True)).strip().upper()

        if choice in ("", "B", "BACK", "Q"):
            return None
        if choice in ("N", "NEXT"):
            if page_index + 1 < page_count:
                page_index += 1
            continue
        if choice in ("P", "PREV"):
            if page_index > 0:
                page_index -= 1
            continue
        try:
            idx = int(choice)
        except ValueError:
            continue
        if 1 <= idx <= len(page_rooms):
            room = page_rooms[idx - 1]
            room_id = room.get("id") or room.get("slug")
            room_name = room.get("name") or room.get("slug") or room_id
            if room_id:
                return (room_id, room_name)


MAX_FEED_ROWS = 15
FEED_PAGE_SIZE = MAX_FEED_ROWS
MAX_REPLY_ROWS = 15
REPLY_PAGE_SIZE = MAX_REPLY_ROWS
TEXT_PAGE_ROWS = 17
READER_TEXT_WIDTH = p.SCREEN_WIDTH - 1


MAX_COMPOSE_LINES = 200


def _feed_snippet(text: str, width: int, strip_md: bool = False, ellipsis: bool = False) -> str:
    if strip_md:
        text = _strip_markdown(text)
    flat = " ".join((text or "").split())
    if not flat:
        return "(NO TITLE)"
    if len(flat) <= width:
        return flat
    if ellipsis and width > 3:
        return flat[:width - 3] + "..."
    return flat[:width]


def _feed_content_first_line(text: str) -> str:
    text = _collapse_ascii_art_blocks(text or "")
    text = CS_IMAGE_EMBED_RE.sub("[IMAGE]", text)
    text = _strip_markdown(text)
    first_line = text.splitlines()[0] if text else ""
    flat = " ".join(first_line.split())
    if not flat.replace("[IMAGE]", "").strip():
        return "(UNTITLED)"
    return flat


def _entry_id(entry: dict) -> str | None:
    return entry.get("postId") or entry.get("id")


MARQUEE_TITLE_WIDTH = 23
MARQUEE_TICK_SEC = 0.45
MARQUEE_GAP = "   "


def _feed_title_display(entry: dict) -> tuple[str, bool]:
    real_title = entry.get("title")
    full = real_title if real_title else _feed_content_first_line(entry.get("content"))
    full = CS_IMAGE_EMBED_RE.sub("[IMAGE]", full)
    full = _strip_markdown(full)
    if not p.petscii_safe(full).strip():
        full = "(UNTITLED)"
    if entry.get("isNSFW"):
        full = f"[NSFW] {full}"
    full = p.petscii_safe(full)
    return full, len(full) > MARQUEE_TITLE_WIDTH


def _marquee_window(text: str, width: int, offset: int) -> str:
    loop_str = text + MARQUEE_GAP
    offset %= len(loop_str)
    doubled = loop_str * 2
    return doubled[offset:offset + width]


FEED_ROW_WIDTH = 39


def _feed_row_bytes(i: int, entry: dict, highlighted: bool, viewed_ids: set[str],
                     window: str | None = None) -> bytes:
    full_title, marqueeable = _feed_title_display(entry)
    shown = window if window is not None else full_title[:MARQUEE_TITLE_WIDTH]
    author = entry.get("authorUsername") or "?"

    out = bytearray()
    if highlighted:
        out += p.RVS_ON
    out += p.COLOR["yellow"]
    out += p.encode(f"{i:>2} ")
    if highlighted:
        out += p.COLOR["white"]
    elif marqueeable and _entry_id(entry) not in viewed_ids:
        out += p.COLOR["light_green"]
    else:
        out += p.COLOR["white"]
    out += p.encode(f"{shown:<23}"[:23])
    out += p.COLOR["white"]
    out += p.encode(f"@{author}"[:13])
    if highlighted:
        out += p.RVS_OFF
    out += p.COLOR["white"] + p.RETURN
    return bytes(out)


def _new_items_alert_row(count: int, noun: str, width: int = p.SCREEN_WIDTH) -> bytes:
    if count <= 0:
        return p.line("", width) + p.COLOR["white"]
    plural = "" if count == 1 else "S"
    text = f"{count} NEW {noun}{plural} -- PRESS R"
    return p.COLOR["light_green"] + p.line(text, width) + p.COLOR["white"]


def _draw_feed_page(page_index: int, page: dict, entries: list[dict], selected: int,
                     viewed_ids: set[str], window: str | None = None,
                     new_count: int = 0) -> bytes:
    out = bytearray()
    out += p.CLR
    out += p.COLOR["yellow"]
    out += p.header_bar(f"FEED -- PAGE {page_index + 1}", width=FEED_ROW_WIDTH)
    out += p.COLOR["white"]
    out += _new_items_alert_row(new_count, "POST", width=FEED_ROW_WIDTH)
    if not entries:
        out += p.status_line("NOTHING HERE.", width=FEED_ROW_WIDTH)
    for i, entry in enumerate(entries, start=1):
        row_window = window if (i - 1) == selected else None
        out += _feed_row_bytes(i, entry, (i - 1) == selected, viewed_ids, row_window)
    out += p.COLOR["white"]
    out += p.rule(width=FEED_ROW_WIDTH)
    out += p.COLOR["white"]

    hint_parts = ["W/S=MOVE", "RETURN=READ"]
    if page.get("cursor"):
        hint_parts.append("N=NEXT")
    if page_index > 0:
        hint_parts.append("P=PREV")
    hint_parts.append("Q=BACK")
    out += p.status_line(" ".join(hint_parts), width=FEED_ROW_WIDTH)
    return bytes(out)


async def _redraw_feed_row(conn: TelnetConn, i: int, entry: dict, viewed_ids: set[str],
                            window: str):
    await conn.write(p.HOME)
    await conn.write(p.CRSR_DOWN * (i + 1))
    await conn.write(_feed_row_bytes(i, entry, True, viewed_ids, window))


async def _wait_for_feed_action(conn: TelnetConn, entries: list[dict], selected: int,
                                 viewed_ids: set[str],
                                 refresh_event: asyncio.Event | None = None) -> str:
    offset = 0
    key_task = asyncio.create_task(conn.read_key())
    try:
        while True:
            timer_task = asyncio.create_task(asyncio.sleep(MARQUEE_TICK_SEC))
            wait_set = {key_task, timer_task}
            refresh_task = asyncio.create_task(refresh_event.wait()) if refresh_event else None
            if refresh_task is not None:
                wait_set.add(refresh_task)
            done, _ = await asyncio.wait(wait_set, return_when=asyncio.FIRST_COMPLETED)

            if refresh_task is not None and refresh_task in done:
                timer_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await timer_task
                refresh_event.clear()
                return "NEW_AVAILABLE"
            if refresh_task is not None and not refresh_task.done():
                refresh_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await refresh_task

            if key_task not in done:
                timer_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await timer_task
                if entries and 0 <= selected < len(entries):
                    entry = entries[selected]
                    full_title, marqueeable = _feed_title_display(entry)
                    if marqueeable and _entry_id(entry) not in viewed_ids:
                        offset += 1
                        window = _marquee_window(full_title, MARQUEE_TITLE_WIDTH, offset)
                        await _redraw_feed_row(conn, selected + 1, entry, viewed_ids, window)
                continue

            timer_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await timer_task
            byte = key_task.result()
            if byte == 0x0D:
                return "OPEN"
            ch = chr(byte).upper() if 32 <= byte < 127 else ""
            if ch == "W":
                return "UP"
            if ch == "S":
                return "DOWN"
            if ch == "Q":
                return "QUIT"
            if ch == "N":
                return "NEXT"
            if ch == "P":
                return "PREV"
            if ch == "R":
                return "PULL_NEW"

            key_task = asyncio.create_task(conn.read_key())
    finally:
        if not key_task.done():
            key_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await key_task


def _reply_id(reply: dict) -> str | None:


    return reply.get("replyId") or reply.get("id")


def _reply_parent_id(reply: dict) -> str | None:


    return reply.get("parentReplyId") or reply.get("parentId")


async def compose_multiline(conn: TelnetConn, header: str) -> str | None:
    await conn.clear()
    await conn.write(p.COLOR["yellow"])
    await conn.write(p.header_bar(header))
    await conn.write(p.COLOR["white"])
    await conn.write(p.status_line("TYPE YOUR TEXT, ONE LINE AT A TIME."))
    await conn.write(p.status_line("/SEND ALONE TO POST, /CANCEL TO ABORT."))
    await conn.write(p.COLOR["white"])
    await conn.write(p.rule())
    await conn.write(p.COLOR["white"])
    lines: list[str] = []
    while True:
        await conn.write(p.input_prompt())
        raw = await conn.read_line(allow_case_toggle=True)
        cmd = raw.strip().upper()
        if cmd == "/SEND":
            return "\n".join(lines)
        if cmd == "/CANCEL":
            return None
        if len(lines) < MAX_COMPOSE_LINES:
            lines.append(raw)


async def _show_post_result(conn: TelnetConn, header: str, color: bytes,
                             extra_line: str | None = None):
    await conn.clear()
    await conn.write(color)
    await conn.write(p.header_bar(header))
    await conn.write(p.COLOR["white"])
    if extra_line:
        for wline in p.wrap(extra_line):
            await conn.write_line(wline)
        await conn.write_line()
    await conn.write(p.status_line("PRESS ANY KEY TO CONTINUE."))
    await conn.read_key()


async def _post_reply(conn: TelnetConn, client: CyberSpaceClient, post_id: str,
                       parent_reply_id: str | None = None, header: str = "REPLY"):
    body = await compose_multiline(conn, header)
    if body is None or not body.strip():
        return
    await conn.clear()
    try:
        async with loading(conn, "POSTING"):
            await client.replies_create(post_id, body, parent_reply_id=parent_reply_id)
        await _show_post_result(conn, "REPLY POSTED", p.COLOR["light_green"])
    except CyberSpaceError as e:
        await _show_post_result(conn, "REPLY FAILED", p.COLOR["light_red"], e.message)


def _entry_display_title(entry: dict) -> str:
    title = _strip_markdown(entry.get("title") or "") or "(UNTITLED)"
    if entry.get("isNSFW"):
        title = f"[NSFW] {title}"
    return title


async def reply_to_entry(conn: TelnetConn, client: CyberSpaceClient, entry: dict):
    post_id = entry.get("postId") or entry.get("id")
    if not post_id:
        return
    header = f"REPLY TO: {_entry_display_title(entry)}"
    await _post_reply(conn, client, post_id, header=header)


async def write_post(conn: TelnetConn, client: CyberSpaceClient, me: dict):
    await conn.clear()
    await conn.write(p.COLOR["yellow"])
    await conn.write(p.header_bar("WRITE A POST"))
    await conn.write(p.COLOR["white"])
    await conn.write(p.status_line("TITLE+TOPICS OPTIONAL, /CANCEL TO ABORT"))
    await conn.write(p.COLOR["yellow"] + p.encode("TITLE: ") + p.COLOR["white"])
    title_raw = (await conn.read_line(allow_case_toggle=True)).strip()
    if title_raw.upper() == "/CANCEL":
        await _show_post_result(conn, "CANCELLED", p.COLOR["light_red"], "NOTHING WAS POSTED.")
        return
    title = title_raw[:100]

    await conn.write(p.COLOR["yellow"] + p.encode("TOPICS (MAX 3, CSV): ") + p.COLOR["white"])
    topics_raw = (await conn.read_line(allow_case_toggle=True)).strip()
    if topics_raw.upper() == "/CANCEL":
        await _show_post_result(conn, "CANCELLED", p.COLOR["light_red"], "NOTHING WAS POSTED.")
        return
    topics = [t.strip().lower() for t in topics_raw.split(",") if t.strip()][:3] or None

    await conn.write(p.COLOR["yellow"] + p.encode("NSFW? (Y/N): ") + p.COLOR["white"])
    nsfw_raw = (await conn.read_line()).strip().upper()
    if nsfw_raw == "/CANCEL":
        await _show_post_result(conn, "CANCELLED", p.COLOR["light_red"], "NOTHING WAS POSTED.")
        return
    is_nsfw = nsfw_raw.startswith("Y")

    body = await compose_multiline(conn, "POST BODY")
    if body is None or not body.strip():
        await _show_post_result(conn, "CANCELLED", p.COLOR["light_red"], "NOTHING WAS POSTED.")
        return

    try:
        async with loading(conn, "POSTING"):
            result = await client.entries_create(
                body, title=title or None, topics=topics, is_nsfw=is_nsfw,
            )
        slug = result.get("slug") if isinstance(result, dict) else None
        await _show_post_result(
            conn, "POSTED!", p.COLOR["light_green"],
            f"SLUG: {slug}" if slug else None,
        )
    except CyberSpaceError as e:
        await _show_post_result(conn, "POST FAILED", p.COLOR["light_red"], e.message)


async def paginated_reader(conn: TelnetConn, title: str, meta_line: str,
                            content: str, action_keys: dict[str, str],
                            meta_color: bytes | None = None) -> str | None:
    body_lines: list[str] = []
    for para in (content or "").split("\n"):
        if not para.strip():
            body_lines.append("")
            continue
        body_lines.extend(p.wrap(para, width=READER_TEXT_WIDTH))
    if not body_lines:
        body_lines = ["(NO CONTENT)"]

    total_pages = max(1, (len(body_lines) + TEXT_PAGE_ROWS - 1) // TEXT_PAGE_ROWS)
    page = 0
    while True:
        await conn.clear()
        await conn.write(p.COLOR["yellow"])
        await conn.write(p.header_bar(title))
        await conn.write(meta_color or p.COLOR["white"])
        await conn.write_line(meta_line[:p.SCREEN_WIDTH])
        await conn.write(p.rule())
        await conn.write(p.COLOR["white"])
        start = page * TEXT_PAGE_ROWS
        for line in body_lines[start:start + TEXT_PAGE_ROWS]:
            await conn.write_line(line)
        await conn.write(p.COLOR["white"])
        await conn.write(p.rule())
        more = page + 1 < total_pages
        at_bottom = not more and total_pages > 1


        if more:
            await conn.write(p.status_line("PRESS ANY KEY TO CONTINUE READING"))
        elif at_bottom:
            await conn.write(p.status_line("PRESS T TO TRAVEL TO TOP"))
        page_hint = f"PAGE {page + 1}/{total_pages} -- "
        page_hint += " ".join(f"{key}={label}" for key, label in action_keys.items())
        await conn.write(p.status_line(page_hint[:p.SCREEN_WIDTH]))
        await conn.write(p.COLOR["white"])
        key = await conn.read_key()
        ch = chr(key).upper() if 32 <= key < 127 else ""
        if ch == "T":


            page = 0
            continue
        if ch in action_keys:
            return ch
        if more:
            page += 1
        else:
            return None


async def read_reply(conn: TelnetConn, client: CyberSpaceClient, post_id: str, reply: dict,
                      parent: dict | None = None, me: dict | None = None):
    author = reply.get("authorUsername") or "?"
    created = (reply.get("createdAt") or "")[:10]
    title = f"REPLY BY {author}"
    meta = created
    if parent:
        meta = f"{created} -- REPLYING TO @{parent.get('authorUsername') or '?'}"
    action_keys = {"R": "REPLY", "P": "POST", "Q": "BACK"}
    if parent:


        action_keys = {"R": "REPLY", "U": "UP", "P": "POST", "Q": "BACK"}
    while True:
        key = await paginated_reader(conn, title, meta, _render_post_content(reply), action_keys)
        if key == "R":
            await _post_reply(conn, client, post_id, parent_reply_id=_reply_id(reply),
                               header=f"REPLY TO {author}")
            continue
        if key == "U" and parent:


            grandparent = None
            gp_id = _reply_parent_id(parent)
            if gp_id:
                try:
                    grandparent = await client.replies_get(gp_id)
                except CyberSpaceError:
                    grandparent = None
            await read_reply(conn, client, post_id, parent, parent=grandparent, me=me)
            continue
        if key == "P":
            try:
                await conn.clear()
                async with loading(conn, "LOADING POST"):
                    entry = await client.entries_get(post_id)
                await read_entry(conn, client, entry, me=me)
            except CyberSpaceError as e:
                await conn.write(p.COLOR["light_red"])
                await conn.write_line(f"COULDN'T LOAD POST: {e.message.upper()}"[:p.SCREEN_WIDTH])
                await conn.write(p.COLOR["white"])
                await asyncio.sleep(1.5)
            continue
        return


MAX_REPLY_INDENT = 3


async def view_replies(conn: TelnetConn, client: CyberSpaceClient, entry: dict,
                        me: dict | None = None):
    post_id = entry.get("postId") or entry.get("id")
    if not post_id:
        return
    my_username = (me or {}).get("username", "")
    pages: list[dict] = []
    depth_by_id: dict[str, int] = {}
    reply_by_id: dict[str, dict] = {}

    def index_replies(replies: list[dict]):
        for reply in replies:
            rid = _reply_id(reply)
            pid = _reply_parent_id(reply)
            depth = depth_by_id.get(pid, -1) + 1 if pid else 0
            if rid:
                depth_by_id[rid] = depth
                reply_by_id[rid] = reply

    async def load_page(cursor: str | None) -> dict:
        result = await client.replies_list(post_id, limit=REPLY_PAGE_SIZE, cursor=cursor)
        replies = result.get("data") or []
        index_replies(replies)
        return {"replies": replies, "cursor": result.get("cursor")}

    await conn.clear()
    await conn.write(p.COLOR["yellow"])
    await conn.write(p.header_bar("REPLIES"))
    await conn.write(p.COLOR["white"])
    try:
        async with loading(conn, "LOADING REPLIES"):
            pages.append(await load_page(None))
    except CyberSpaceError as e:
        await _show_post_result(conn, "COULDN'T LOAD REPLIES", p.COLOR["light_red"], e.message)
        return

    page_index = 0
    while True:
        page = pages[page_index]
        replies = page["replies"][:MAX_REPLY_ROWS]

        await conn.clear()
        await conn.write(p.COLOR["yellow"])
        await conn.write(p.header_bar(f"REPLIES -- PAGE {page_index + 1}"))
        await conn.write(p.COLOR["white"])
        if not replies:
            await conn.write(p.status_line("NO REPLIES YET."))
        for i, reply in enumerate(replies, start=1):
            rid = _reply_id(reply)
            depth = depth_by_id.get(rid, 0)
            if depth <= MAX_REPLY_INDENT:


                marker = ">" * depth + (" " if depth else "")
            else:


                marker = f">{depth} "
            snippet_width = max(5, 23 - len(marker))
            snippet = _feed_snippet(reply.get("content"), snippet_width, strip_md=True)
            author = reply.get("authorUsername") or "?"
            is_mine = bool(my_username) and author.lower() == my_username.lower()
            await conn.write(p.COLOR["yellow"])
            await conn.write(p.encode(f"{i:>2} "))
            if marker:
                await conn.write(p.COLOR["white"])
                await conn.write(p.encode(marker))
            await conn.write(p.COLOR["light_green"] if is_mine else p.COLOR["white"])
            await conn.write(p.encode(f"{snippet:<{snippet_width}}"[:snippet_width]))
            await conn.write(p.COLOR["white"])
            await conn.write_line(f"@{author}"[:14])
        await conn.write(p.COLOR["white"])
        await conn.write(p.rule())
        await conn.write(p.COLOR["white"])

        hint_parts = ["#=READ"]
        if page.get("cursor"):
            hint_parts.append("N=NEXT")
        if page_index > 0:
            hint_parts.append("P=PREV")
        hint_parts.append("Q=BACK")
        await conn.write(p.status_line(" ".join(hint_parts)))
        await conn.write(p.input_prompt("REPLIES"))
        choice = (await conn.read_line(allow_case_toggle=True)).strip().upper()

        if choice == "":
            continue
        if choice in ("Q", "BACK"):
            return
        if choice == "N":
            if page.get("cursor"):
                if page_index + 1 >= len(pages):
                    try:
                        async with loading(conn):
                            pages.append(await load_page(page["cursor"]))
                    except CyberSpaceError as e:
                        await conn.write(p.COLOR["light_red"])
                        await conn.write_line(f"ERROR: {e.message.upper()}"[:p.SCREEN_WIDTH])
                        await conn.write(p.COLOR["white"])
                        await asyncio.sleep(1)
                        continue
                page_index += 1
            continue
        if choice == "P":
            if page_index > 0:
                page_index -= 1
            continue
        try:
            idx = int(choice)
        except ValueError:
            continue
        if 1 <= idx <= len(replies):
            picked = replies[idx - 1]
            parent = reply_by_id.get(_reply_parent_id(picked))
            await read_reply(conn, client, post_id, picked, parent=parent, me=me)


def _render_post_content(item: dict) -> str:
    def _is_art(d: dict) -> bool:
        return str(d.get("type") or "").lower() == "art" or bool(d.get("isArt"))

    def _media_line(d: dict) -> str | None:
        if d.get("imageUrl") or str(d.get("type") or "").lower() == "image":
            return "[IMAGE]"
        if d.get("gifUrl") or str(d.get("type") or "").lower() == "gif":
            return "[GIF]"
        if d.get("audioAttachment") or str(d.get("type") or "").lower() in ("audio", "song"):
            return "[SONG]"
        return None

    candidates = [item, *(a for a in (item.get("attachments") or []) if isinstance(a, dict))]
    if any(_is_art(c) for c in candidates):
        return "[ASCII ART]"

    lines = [line for c in candidates[1:] for line in [_media_line(c)] if line]
    top_level_line = _media_line(item)
    if top_level_line and top_level_line not in lines:
        lines.insert(0, top_level_line)

    content = item.get("content") or ""
    if content:


        content = _collapse_ascii_art_blocks(content)
        content = CS_IMAGE_EMBED_RE.sub("[IMAGE]", content)
        content = _strip_markdown(content)
        content = URL_RE.sub("[WEB LINK]", content)

    if lines:
        return "\n".join(lines) + ("\n\n" + content if content else "")
    return content


async def read_entry(conn: TelnetConn, client: CyberSpaceClient, entry: dict,
                      me: dict | None = None):
    title = _entry_display_title(entry)
    author = entry.get("authorUsername") or "?"
    created = (entry.get("createdAt") or "")[:10]
    replies_count = entry.get("repliesCount")
    meta = f"BY {author}  {created}"
    if replies_count:
        meta += f"  ({replies_count} REPLIES)"

    action_keys = {"R": "REPLY", "V": "REPLIES", "Q": "BACK"}
    while True:
        key = await paginated_reader(conn, title, meta, _render_post_content(entry), action_keys)
        if key == "R":
            await reply_to_entry(conn, client, entry)
            continue
        if key == "V":
            await view_replies(conn, client, entry, me=me)
            continue
        return


async def feed_viewer(conn: TelnetConn, client: CyberSpaceClient, me: dict | None = None):
    pages: list[dict] = []


    viewed_ids: set[str] = set()

    async def load_page(cursor: str | None) -> dict:
        result = await client.entries_list(limit=FEED_PAGE_SIZE, cursor=cursor)
        return {"entries": result.get("data") or [], "cursor": result.get("cursor")}

    await conn.clear()
    await conn.write(p.COLOR["yellow"])
    await conn.write(p.header_bar("FEED VIEWER"))
    await conn.write(p.COLOR["white"])
    try:
        async with loading(conn):
            pages.append(await load_page(None))
    except CyberSpaceError as e:
        await conn.clear()
        await conn.write(p.COLOR["light_red"])
        for wline in p.wrap(f"COULDN'T LOAD FEED: {e.message.upper()}"):
            await conn.write_line(wline)
        await conn.write(p.COLOR["white"])
        await conn.write_line()
        await conn.write(p.status_line("PRESS ANY KEY TO GO BACK."))
        await conn.read_key()
        return


    pending_new: list[dict] = []
    pending_new_ids: set[str] = set()
    new_entry_event = asyncio.Event()
    stop_poll = asyncio.Event()

    def _new_feed_entries(fresh_entries: list[dict]) -> list[dict]:
        existing_ids = {_entry_id(e) for e in pages[0]["entries"]}
        return [e for e in fresh_entries
                if _entry_id(e) not in existing_ids and _entry_id(e) not in pending_new_ids]

    async def poller():
        while not stop_poll.is_set():
            try:
                await client.ensure_fresh_token()
                fresh = await load_page(None)
                newly_found = _new_feed_entries(fresh["entries"])
                if newly_found:
                    pending_new[0:0] = newly_found
                    pending_new_ids.update(_entry_id(e) for e in newly_found)
                    new_entry_event.set()
            except CyberSpaceError:
                pass
            except Exception as e:


                print(f"[!] feed poller: {e!r} -- will retry")
            try:
                await asyncio.wait_for(stop_poll.wait(), timeout=LIST_POLL_INTERVAL_SEC)
            except asyncio.TimeoutError:
                pass

    poll_task = asyncio.create_task(poller())
    try:
        page_index = 0
        selected = 0
        while True:
            page = pages[page_index]
            entries = page["entries"][:MAX_FEED_ROWS]
            selected = max(0, min(selected, len(entries) - 1)) if entries else 0

            new_count = len(pending_new) if page_index == 0 else 0
            await conn.write(_draw_feed_page(page_index, page, entries, selected, viewed_ids,
                                              new_count=new_count))

            refresh_event = new_entry_event if page_index == 0 else None
            action = await _wait_for_feed_action(conn, entries, selected, viewed_ids,
                                                  refresh_event=refresh_event)

            if action == "QUIT":
                return
            if action == "NEW_AVAILABLE":
                continue
            if action == "PULL_NEW":
                if pending_new:
                    prev_id = _entry_id(entries[selected]) if entries else None
                    page["entries"][0:0] = pending_new
                    pending_new.clear()
                    pending_new_ids.clear()
                    selected = 0
                    if prev_id is not None:
                        for idx, e in enumerate(page["entries"][:MAX_FEED_ROWS]):
                            if _entry_id(e) == prev_id:
                                selected = idx
                                break
                continue
            if action == "UP":
                selected -= 1
                continue
            if action == "DOWN":
                selected += 1
                continue
            if action == "NEXT":
                if page.get("cursor"):
                    if page_index + 1 >= len(pages):
                        try:
                            async with loading(conn):
                                pages.append(await load_page(page["cursor"]))
                        except CyberSpaceError as e:
                            await conn.write(p.COLOR["light_red"])
                            await conn.write_line(f"ERROR: {e.message.upper()}"[:p.SCREEN_WIDTH])
                            await conn.write(p.COLOR["white"])
                            await asyncio.sleep(1)
                            continue
                    page_index += 1
                    selected = 0
                continue
            if action == "PREV":
                if page_index > 0:
                    page_index -= 1
                    selected = 0
                continue
            if action == "OPEN" and entries:
                eid = _entry_id(entries[selected])
                if eid:
                    viewed_ids.add(eid)
                await read_entry(conn, client, entries[selected], me=me)
    finally:
        stop_poll.set()
        poll_task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await poll_task


MAX_VISIBLE_LINES = 18


async def play_join_tune(conn: TelnetConn):
    await conn.write(b"\x07")


async def chat_room(conn: TelnetConn, client: CyberSpaceClient, room_id: str, me: dict,
                     room_name: str | None = None):
    my_username = me.get("username", "")
    header_label = (room_name or room_id).upper()


    message_blocks: list[list[tuple[list[tuple[bytes | None, str]], bool]]] = []


    scroll_offset = 0


    earliest_ts: int | None = None
    has_more_history = True


    idle_after_ms: int | None = None


    heartbeat_ms: int | None = None
    last_presence_sent = 0.0

    def note_presence_info(info):
        nonlocal idle_after_ms, heartbeat_ms
        if isinstance(info, dict):
            if info.get("idleAfterMs"):
                idle_after_ms = info["idleAfterMs"]
            if info.get("heartbeatMs"):
                heartbeat_ms = info["heartbeatMs"]


    viewing_subscreen = False

    async def draw_footer():
        await conn.write(p.COLOR["yellow"])
        await conn.write(p.header_bar(f"# {header_label} CHAT"))
        await conn.write(p.COLOR["white"])
        if scroll_offset > 0:
            await conn.write(p.status_line(
                f"VIEWING HISTORY (-{scroll_offset}). /L=LATEST /D=DOWN"))
        else:
            await conn.write(p.status_line("TYPE A MESSAGE + RETURN TO SEND."))
            await conn.write(p.status_line("/QUIT=LEAVE /HELP=CMDS UP-ARROW=CASE"))
        await conn.write(p.COLOR["white"])
        await conn.write(p.rule())
        await conn.write(p.COLOR["white"])

    def visible_rows() -> list[tuple[list[tuple[bytes | None, str]], bool]]:
        if not message_blocks:
            return []
        end = max(0, min(len(message_blocks) - scroll_offset, len(message_blocks)))
        rows: list[tuple[list[tuple[bytes | None, str]], bool]] = []
        for block in message_blocks[:end]:
            rows.extend(block)
        return rows[-MAX_VISIBLE_LINES:]

    async def redraw(show_prompt: bool = True, flash: bool = False):
        await conn.busy_event.wait()
        if viewing_subscreen:
            return
        await conn.clear()
        rows = visible_rows()
        for _ in range(MAX_VISIBLE_LINES - len(rows)):
            await conn.write_line()
        for segments, _lowercase in rows:
            await conn.write(p.segment_line(segments))
        await draw_footer()
        if flash:
            async with loading(conn, "NEW MSG"):
                await asyncio.sleep(NEW_MESSAGE_FLASH_SEC)
        if show_prompt:
            await conn.write(p.input_prompt())

    await redraw(show_prompt=False)

    last_seen_ts = 0
    seen_ids: set[str] = set()
    prompt_active = False

    async def show_prompt():
        nonlocal prompt_active
        await conn.write(p.input_prompt())
        prompt_active = True

    async def show_who_screen():
        nonlocal viewing_subscreen


        viewing_subscreen = True
        users = await client.circ_users(room_id)
        await conn.busy_event.wait()


        def is_idle(u: dict, now_ms: int) -> bool:
            last_activity = u.get("lastActivity")
            return last_activity is not None and (now_ms - last_activity) > (
                idle_after_ms or DEFAULT_IDLE_AFTER_MS)

        def roster_signature(users: list[dict]) -> frozenset:
            now_ms = int(time.time() * 1000)
            return frozenset((u["username"], is_idle(u, now_ms)) for u in users)

        async def draw_roster(users: list[dict]):
            now_ms = int(time.time() * 1000)
            idle_count = sum(1 for u in users if is_idle(u, now_ms))
            await conn.clear()
            await conn.write(p.COLOR["yellow"])
            noun = "PERSON" if len(users) == 1 else "PEOPLE"
            title = f"{len(users)} {noun} ONLINE -- # {header_label}"
            if idle_count:
                title = f"{len(users)} ONLINE ({idle_count} IDLE) -- # {header_label}"
            await conn.write(p.header_bar(title))
            await conn.write(p.COLOR["white"])
            await conn.write(p.rule())
            await conn.write(p.COLOR["white"])
            if not users:
                await conn.write(p.status_line("...JUST YOU FOR NOW."))


            MAX_WHO_ROWS = 19
            for u in users[:MAX_WHO_ROWS]:
                segments = [(p.color_for(u["username"]), f"* {u['username']}")]
                if is_idle(u, now_ms):
                    segments.append((p.COLOR["white"], " ZZZ"))
                await conn.write(p.segment_line(segments))
            if len(users) > MAX_WHO_ROWS:
                await conn.write(p.COLOR["white"])
                await conn.write_line(f"...AND {len(users) - MAX_WHO_ROWS} MORE.")
            await conn.write(p.COLOR["white"])
            await conn.write(p.rule())
            await conn.write(p.status_line("PRESS ANY KEY TO GO BACK TO CHAT."))
            await conn.write(p.COLOR["white"])

        await draw_roster(users)
        signature = roster_signature(users)

        key_task = asyncio.create_task(conn.read_key())
        try:
            while True:
                timer_task = asyncio.create_task(asyncio.sleep(WHO_POLL_INTERVAL_SEC))
                done, _ = await asyncio.wait({key_task, timer_task},
                                              return_when=asyncio.FIRST_COMPLETED)
                if key_task in done:
                    timer_task.cancel()
                    with contextlib.suppress(asyncio.CancelledError):
                        await timer_task
                    break

                try:
                    fresh_users = await client.circ_users(room_id)
                except CyberSpaceError:
                    continue
                fresh_signature = roster_signature(fresh_users)
                if fresh_signature != signature:
                    users, signature = fresh_users, fresh_signature
                    await conn.busy_event.wait()
                    await draw_roster(users)
        finally:
            if not key_task.done():
                key_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await key_task
        viewing_subscreen = False
        await redraw(show_prompt=False)

    async def show_help_screen():
        nonlocal viewing_subscreen
        viewing_subscreen = True
        await conn.busy_event.wait()
        await conn.clear()
        await conn.write(p.COLOR["yellow"])
        await conn.write(p.header_bar("COMMAND LIST"))
        await conn.write(p.COLOR["white"])
        await conn.write(p.rule())
        await conn.write(p.COLOR["white"])
        commands = [
            ("/HELP", "THIS SCREEN"),
            ("/WHO", "WHO'S HERE"),
            ("/U", "SCROLL UP 1 MSG"),
            ("/D", "SCROLL DOWN 1 MSG"),
            ("/L", "JUMP TO LATEST"),
            ("/QUIT", "LEAVE ROOM"),
            ("/FORTUNE", "RANDOM FORTUNE"),
            ("/8BALL <QUESTION>", "MAGIC 8-BALL"),
            ("/RAINBOW <MESSAGE>", "RAINBOW TEXT"),
            ("/SLOW <MESSAGE>", "S P A C E D   O U T"),
            ("/SLAP <@USER>", "SLAP SOMEONE"),
            ("/HI5 <@USER>", "HIGH-FIVE SOMEONE"),
            ("UP ARROW", "TOGGLE TYPE CASE"),
        ]
        for cmd, desc in commands:
            await conn.write(p.COLOR["yellow"])
            await conn.write(p.encode(f"{cmd:<12}"))
            await conn.write(p.COLOR["white"])
            await conn.write_line(desc)
        await conn.write(p.COLOR["white"])
        await conn.write(p.rule())
        await conn.write(p.status_line("PRESS ANY KEY TO GO BACK TO CHAT."))
        await conn.write(p.COLOR["white"])
        await conn.read_key()
        viewing_subscreen = False
        await redraw(show_prompt=False)

    def divider_row() -> tuple[list[tuple[bytes | None, str]], bool]:


        return ([(p.COLOR["white"], "-" * p.SCREEN_WIDTH)], False)

    def message_id(msg: dict) -> str | None:


        return msg.get("id") or msg.get("messageId")

    def format_message_lines(msg: dict, username: str) -> list[list[tuple[bytes | None, str]]]:
        content = msg.get("content") or ""
        uname_color = p.color_for(username)
        lines_to_send: list[list[tuple[bytes | None, str]]] = []

        style = msg.get("style")
        style_list = style if isinstance(style, list) else ([style] if style else [])
        is_art = "art" in style_list
        is_rainbow = "rainbow" in style_list

        if is_art:
            lines_to_send.append([(uname_color, f"<{username}> [ASCII ART]")])
            return lines_to_send

        if msg.get("imageUrl"):
            lines_to_send.append([(uname_color, f"<{username}> [IMAGE]")])
        if msg.get("gifUrl"):
            lines_to_send.append([(uname_color, f"<{username}> [GIF]")])
        audio = msg.get("audioAttachment")
        if audio:
            lines_to_send.append([(uname_color, f"<{username}> [SONG]")])

        skip_content = content and (
            content in (msg.get("imageUrl"), msg.get("gifUrl")) or audio)


        display_text = content
        label = None
        if not display_text and msg.get("isFortune"):
            display_text = msg.get("fortuneText") or ""
            label = "FORTUNE"
        elif not display_text and msg.get("isEightball"):
            display_text = msg.get("eightballAnswer") or ""
            label = "8-BALL"


        if display_text:
            display_text = URL_RE.sub("[WEB LINK]", display_text)

        if display_text and not skip_content:
            if msg.get("isAction"):
                prefix = f"* {username} "
            elif label:
                prefix = f"<{username}> [{label}] "
            else:
                prefix = f"<{username}> "


            ts_indent = " " * len("[HH:MM] ")
            wrap_width = p.SCREEN_WIDTH - len(ts_indent)
            char_offset = 0
            for i, wline in enumerate(p.wrap(prefix + display_text, width=wrap_width)):
                if i > 0:
                    wline = ts_indent + wline
                if is_rainbow:
                    segments = [
                        (p.rainbow_color(char_offset + j), ch) for j, ch in enumerate(wline)
                    ]
                    char_offset += len(wline)
                    lines_to_send.append(segments)
                else:
                    lines_to_send.append([(uname_color, wline)])
        elif not lines_to_send:
            lines_to_send.append([(uname_color, f"<{username}> [EMPTY MESSAGE]")])

        return lines_to_send

    def build_message_rows(msg: dict, username: str,
                            lowercase: bool = False) -> list[tuple[list[tuple[bytes | None, str]], bool]]:
        ts_ms = msg.get("timestamp") or int(time.time() * 1000)
        ts_segment = (p.COLOR["yellow"], f"[{p.local_timestamp(ts_ms)}] ")

        if msg.get("deleted"):
            return [
                ([ts_segment, (p.color_for(username), f"<{username}> [DELETED]")], False),
                divider_row(),
            ]

        rows: list[tuple[list[tuple[bytes | None, str]], bool]] = []
        for i, line_segments in enumerate(format_message_lines(msg, username)):
            segments = [ts_segment] + line_segments if i == 0 else line_segments
            rows.append((segments, lowercase))
        rows.append(divider_row())
        return rows

    def append_message(msg: dict, username: str, lowercase: bool = False):
        message_blocks.append(build_message_rows(msg, username, lowercase))

    async def load_older_history() -> bool:
        nonlocal earliest_ts, has_more_history
        if not has_more_history or earliest_ts is None:
            return False
        try:
            page = await client.circ_read_room(room_id, limit=20, before=earliest_ts)
        except CyberSpaceError:
            return False
        older = page.get("data") or []
        if not older:
            has_more_history = False
            return False
        new_blocks = []
        for msg in older:
            mid = message_id(msg)
            if mid is not None:
                seen_ids.add(mid)
            earliest_ts = min(earliest_ts, msg.get("timestamp", earliest_ts))
            new_blocks.append(build_message_rows(msg, msg["username"]))
        message_blocks[0:0] = new_blocks
        if len(older) < 20:
            has_more_history = False
        return True

    def mentions_me(msg: dict) -> bool:
        if not my_username or msg.get("username") == my_username:
            return False
        text = " ".join(
            str(msg.get(field) or "")
            for field in ("content", "fortuneText", "eightballAnswer")
        )
        if not text:
            return False
        return re.search(rf"@{re.escape(my_username)}\b", text, re.IGNORECASE) is not None

    async def render_new(history: list[dict], flash: bool = False):
        nonlocal last_seen_ts, prompt_active
        added_any = False
        for msg in history:
            mid = message_id(msg)
            if mid is not None and mid in seen_ids:
                continue
            if mid is not None:
                seen_ids.add(mid)
            last_seen_ts = max(last_seen_ts, msg.get("timestamp", 0))
            append_message(msg, msg["username"])
            added_any = True
            if mentions_me(msg):

                await conn.write(b"\x07")

        if added_any:
            await redraw(show_prompt=prompt_active, flash=flash)


    try:
        initial = await client.circ_read_room(room_id, limit=20)
    except CyberSpaceError as e:
        await conn.clear()
        await conn.write(p.COLOR["light_red"])
        for wline in p.wrap(f"COULDN'T JOIN #{header_label}: {e.message.upper()}"):
            await conn.write_line(wline)
        await conn.write(p.COLOR["white"])
        await conn.write_line()
        await conn.write(p.status_line("PRESS ANY KEY TO GO BACK."))
        await conn.read_key()
        return
    initial_data = initial["data"]
    if initial_data:
        earliest_ts = min(m.get("timestamp", 0) for m in initial_data)
        if len(initial_data) < 20:
            has_more_history = False
    else:
        has_more_history = False
    await render_new(initial_data)
    await play_join_tune(conn)
    note_presence_info(await client.circ_presence_announce(room_id, int(time.time() * 1000)))
    last_presence_sent = time.monotonic()
    await client.circ_mark_read(room_id)

    stop = asyncio.Event()

    async def poller():
        nonlocal last_presence_sent
        while not stop.is_set():
            try:
                await client.ensure_fresh_token()
                page = await client.circ_read_room(room_id, limit=20)


                await render_new(page["data"], flash=True)


                now = time.monotonic()
                interval_s = (heartbeat_ms or 30_000) / 1000
                if now - last_presence_sent >= interval_s:
                    note_presence_info(
                        await client.circ_presence_announce(room_id, int(time.time() * 1000))
                    )
                    last_presence_sent = now
            except CyberSpaceError:
                pass
            try:
                await asyncio.wait_for(stop.wait(), timeout=POLL_INTERVAL_SEC)
            except asyncio.TimeoutError:
                pass

    poll_task = asyncio.create_task(poller())
    try:
        while True:
            if not prompt_active:
                await show_prompt()
            line = (await conn.read_line(allow_case_toggle=True)).strip()
            prompt_active = False
            if not line:
                continue
            if line.upper() == "/QUIT":
                break
            if line.upper() == "/WHO":
                await show_who_screen()
                continue
            if line.upper() == "/HELP":
                await show_help_screen()
                continue
            if line.upper() == "/U":


                if scroll_offset >= len(message_blocks) - 1:
                    await load_older_history()
                scroll_offset = min(scroll_offset + 1, max(0, len(message_blocks) - 1))
                await redraw(show_prompt=False)
                continue
            if line.upper() == "/D":
                scroll_offset = max(scroll_offset - 1, 0)
                await redraw(show_prompt=False)
                continue
            if line.upper() == "/L":
                scroll_offset = 0
                await redraw(show_prompt=False)
                continue


            force_plain_send = False
            if line.upper() == "/SLOW" or line.upper().startswith("/SLOW "):
                _, _, rest = line.partition(" ")
                rest = rest.strip()
                if not rest:
                    continue
                line = " ".join(rest)
                force_plain_send = True
            try:


                if line.startswith("/") and not force_plain_send:
                    command, _, rest = line.partition(" ")
                    sent_text = command.lower() + ((" " + rest) if rest else "")
                else:
                    sent_text = line
                result = await client.circ_send(room_id, sent_text)


                sent_id = None
                if isinstance(result, dict):
                    sent_id = result.get("messageId") or result.get("id")

                msg = None
                if sent_text.startswith("/") and sent_id is not None:


                    for _ in range(3):
                        page = await client.circ_read_room(room_id, limit=20)
                        for candidate in page["data"]:
                            if message_id(candidate) == sent_id:
                                msg = candidate
                                break
                        if msg is not None:
                            break
                        await asyncio.sleep(0.3)

                if msg is None:


                    msg = dict(result) if isinstance(result, dict) else {}
                    msg.setdefault("content", sent_text)
                    msg.setdefault("timestamp", int(time.time() * 1000))
                    if sent_id is not None:
                        msg.setdefault("id", sent_id)

                mid = message_id(msg)


                already_shown = mid is not None and mid in seen_ids
                if mid is not None:
                    seen_ids.add(mid)

                if not already_shown:
                    append_message(msg, my_username)


                scroll_offset = 0


                await redraw(show_prompt=False)
            except CyberSpaceError as e:


                for wline in p.wrap(f"ERROR: {e.message}"):
                    await conn.write_line(wline)
    finally:
        stop.set()
        poll_task.cancel()
        try:
            await client.circ_presence_leave(room_id)
        except CyberSpaceError:
            pass


MAX_CMAIL_ROWS = 16
CMAIL_VISIBLE_LINES = 18
CMAIL_ROW_WIDTH = 39
CMAIL_MESSAGE_WIDTH = 17


def _cmail_message_id(msg: dict) -> str | None:
    return msg.get("id") or msg.get("messageId")


def _format_cmail_message_lines(msg: dict, username: str) -> list[list[tuple[bytes | None, str]]]:
    content = msg.get("content") or ""
    uname_color = p.color_for(username)
    lines_to_send: list[list[tuple[bytes | None, str]]] = []

    style = msg.get("style")
    style_list = style if isinstance(style, list) else ([style] if style else [])
    is_rainbow = "rainbow" in style_list

    if msg.get("imageUrl"):
        lines_to_send.append([(uname_color, f"<{username}> [IMAGE]")])
    if msg.get("gifUrl"):
        lines_to_send.append([(uname_color, f"<{username}> [GIF]")])
    audio = msg.get("audioAttachment")
    if audio:
        lines_to_send.append([(uname_color, f"<{username}> [SONG]")])

    skip_content = content and (
        content in (msg.get("imageUrl"), msg.get("gifUrl")) or audio)

    display_text = content
    label = None
    if not display_text and msg.get("isFortune"):
        display_text = msg.get("fortuneText") or ""
        label = "FORTUNE"
    elif not display_text and msg.get("isEightball"):
        display_text = msg.get("eightballAnswer") or ""
        label = "8-BALL"

    if display_text:
        display_text = URL_RE.sub("[WEB LINK]", display_text)

    if display_text and not skip_content:
        if msg.get("isAction"):
            prefix = f"* {username} "
        elif label:
            prefix = f"<{username}> [{label}] "
        else:
            prefix = f"<{username}> "
        ts_indent = " " * len("[HH:MM] ")
        wrap_width = p.SCREEN_WIDTH - len(ts_indent)
        char_offset = 0
        for i, wline in enumerate(p.wrap(prefix + display_text, width=wrap_width)):
            if i > 0:
                wline = ts_indent + wline
            if is_rainbow:
                segments = [(p.rainbow_color(char_offset + j), ch) for j, ch in enumerate(wline)]
                char_offset += len(wline)
                lines_to_send.append(segments)
            else:
                lines_to_send.append([(uname_color, wline)])
    elif not lines_to_send:
        lines_to_send.append([(uname_color, f"<{username}> [EMPTY MESSAGE]")])

    return lines_to_send


def _build_cmail_message_rows(msg: dict, username: str,
                               lowercase: bool = False) -> list[tuple[list[tuple[bytes | None, str]], bool]]:
    ts_ms = msg.get("timestamp") or int(time.time() * 1000)
    ts_segment = (p.COLOR["yellow"], f"[{p.local_timestamp(ts_ms)}] ")
    rows: list[tuple[list[tuple[bytes | None, str]], bool]] = []
    for i, line_segments in enumerate(_format_cmail_message_lines(msg, username)):
        segments = [ts_segment] + line_segments if i == 0 else line_segments
        rows.append((segments, lowercase))
    rows.append(([(p.COLOR["white"], "-" * p.SCREEN_WIDTH)], False))
    return rows


async def _wait_for_cmail_action(conn: TelnetConn, refresh_event: asyncio.Event | None = None) -> str:
    key_task = asyncio.create_task(conn.read_key())
    try:
        while True:
            wait_set = {key_task}
            refresh_task = asyncio.create_task(refresh_event.wait()) if refresh_event else None
            if refresh_task is not None:
                wait_set.add(refresh_task)
            done, _ = await asyncio.wait(wait_set, return_when=asyncio.FIRST_COMPLETED)

            if refresh_task is not None and refresh_task in done:
                refresh_event.clear()
                return "NEW_AVAILABLE"
            if refresh_task is not None and not refresh_task.done():
                refresh_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await refresh_task

            byte = key_task.result()
            if byte == 0x0D:
                return "OPEN"
            ch = chr(byte).upper() if 32 <= byte < 127 else ""
            if ch == "W":
                return "UP"
            if ch == "S":
                return "DOWN"
            if ch == "N":
                return "COMPOSE"
            if ch == "L":
                return "NEXT"
            if ch == "P":
                return "PREV"
            if ch == "R":
                return "PULL_NEW"
            if ch == "Q":
                return "QUIT"

            key_task = asyncio.create_task(conn.read_key())
    finally:
        if not key_task.done():
            key_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await key_task


def _draw_cmail_row(i: int, convo: dict, highlighted: bool) -> bytes:
    other = convo.get("otherUser") or {}
    uname = other.get("displayName") or other.get("username") or "?"
    unread = convo.get("unreadCount") or 0
    last = _feed_snippet(convo.get("lastMessage") or "", CMAIL_MESSAGE_WIDTH, ellipsis=True)

    out = bytearray()
    if highlighted:
        out += p.RVS_ON
    out += p.COLOR["yellow"]
    out += p.encode(f"{i:>2} ")
    if highlighted:
        out += p.COLOR["white"]
    elif unread:
        out += p.COLOR["light_green"]
    else:
        out += p.COLOR["white"]
    out += p.encode(f"{uname:<12}"[:12])
    out += p.COLOR["white"]
    out += p.encode(" ")
    out += p.encode(f"{last:<{CMAIL_MESSAGE_WIDTH}}"[:CMAIL_MESSAGE_WIDTH])
    if unread:
        out += p.COLOR["light_red"]
        out += p.encode(f" ({unread})")
    if highlighted:
        out += p.RVS_OFF
    out += p.COLOR["white"] + p.RETURN
    return bytes(out)


def _draw_cmail_page(page_index: int, page_count: int, convos: list[dict], selected: int,
                      new_count: int = 0) -> bytes:
    out = bytearray()
    out += p.CLR
    out += p.COLOR["yellow"]
    header = "C-MAIL" if page_count == 1 else f"C-MAIL -- PAGE {page_index + 1}/{page_count}"
    out += p.header_bar(header, width=CMAIL_ROW_WIDTH)
    out += p.COLOR["white"]
    out += _new_items_alert_row(new_count, "MESSAGE", width=CMAIL_ROW_WIDTH)
    if not convos:
        out += p.status_line("NO CONVERSATIONS YET -- N TO START ONE.", width=CMAIL_ROW_WIDTH)
    for i, convo in enumerate(convos, start=1):
        out += _draw_cmail_row(i, convo, (i - 1) == selected)
    out += p.COLOR["white"]
    out += p.rule(width=CMAIL_ROW_WIDTH)
    out += p.COLOR["white"]
    hint_parts = ["W/S=MOVE", "RETURN=OPEN", "N=NEW"]
    if page_count > 1:
        hint_parts.append("L=NEXT")
        if page_index > 0:
            hint_parts.append("P=PREV")
    hint_parts.append("Q=BACK")
    out += p.status_line(" ".join(hint_parts), width=CMAIL_ROW_WIDTH)
    return bytes(out)


async def cmail_inbox(conn: TelnetConn, client: CyberSpaceClient, me: dict,
                       seen_cmail_unread_counts: dict[str, int]):
    await conn.clear()
    try:
        async with loading(conn):
            displayed = await client.cmail_list() or []
    except CyberSpaceError as e:
        await conn.clear()
        await conn.write(p.COLOR["yellow"])
        await conn.write(p.header_bar("C-MAIL"))
        await conn.write(p.COLOR["light_red"])
        await conn.write_line(f"COULDN'T LOAD C-MAIL: {e.message.upper()}")
        await conn.write(p.COLOR["white"])
        await conn.write_line()
        await conn.write(p.status_line("PRESS ANY KEY TO GO BACK."))
        await conn.read_key()
        return

    seen_cmail_unread_counts.update(
        (c.get("conversationId"), c.get("unreadCount") or 0)
        for c in displayed if c.get("conversationId"))

    pending: list[dict] | None = None
    new_count = 0
    new_data_event = asyncio.Event()
    stop_poll = asyncio.Event()

    def _count_new(fresh: list[dict]) -> int:
        current_by_id = {c.get("conversationId"): c for c in displayed if c.get("conversationId")}
        count = 0
        for c in fresh:
            cid = c.get("conversationId")
            if not cid:
                continue
            prior = current_by_id.get(cid)
            if prior is None or (c.get("unreadCount") or 0) > (prior.get("unreadCount") or 0):
                count += 1
        return count

    async def poller():
        nonlocal pending, new_count
        while not stop_poll.is_set():
            try:
                await client.ensure_fresh_token()
                fresh = await client.cmail_list() or []
                count = _count_new(fresh)
                if count:
                    pending, new_count = fresh, count
                    new_data_event.set()
                elif pending is not None:
                    pending, new_count = None, 0
            except CyberSpaceError:
                pass
            except Exception as e:


                print(f"[!] cmail poller: {e!r} -- will retry")
            try:
                await asyncio.wait_for(stop_poll.wait(), timeout=LIST_POLL_INTERVAL_SEC)
            except asyncio.TimeoutError:
                pass

    poll_task = asyncio.create_task(poller())
    try:
        page_index = 0
        selected = 0
        while True:
            page_count = max(1, (len(displayed) - 1) // MAX_CMAIL_ROWS + 1) if displayed else 1
            page_start = page_index * MAX_CMAIL_ROWS
            page_convos = displayed[page_start:page_start + MAX_CMAIL_ROWS]
            selected = max(0, min(selected, len(page_convos) - 1)) if page_convos else 0

            shown_new_count = new_count if page_index == 0 else 0
            await conn.write(_draw_cmail_page(page_index, page_count, page_convos, selected,
                                               new_count=shown_new_count))

            refresh_event = new_data_event if page_index == 0 else None
            action = await _wait_for_cmail_action(conn, refresh_event=refresh_event)

            if action == "QUIT":
                return
            if action == "NEW_AVAILABLE":
                continue
            if action == "PULL_NEW":
                if pending is not None:
                    prev_id = page_convos[selected].get("conversationId") if page_convos else None
                    displayed = pending
                    seen_cmail_unread_counts.update(
                        (c.get("conversationId"), c.get("unreadCount") or 0)
                        for c in displayed if c.get("conversationId"))
                    pending, new_count = None, 0
                    page_index, selected = 0, 0
                    if prev_id is not None:
                        for idx, c in enumerate(displayed[:MAX_CMAIL_ROWS]):
                            if c.get("conversationId") == prev_id:
                                selected = idx
                                break
                continue
            if action == "UP":
                selected -= 1
                continue
            if action == "DOWN":
                selected += 1
                continue
            if action == "NEXT":
                if page_index + 1 < page_count:
                    page_index += 1
                    selected = 0
                continue
            if action == "PREV":
                if page_index > 0:
                    page_index -= 1
                    selected = 0
                continue
            if action == "COMPOSE":
                await conn.write(p.status_line("BLANK USERNAME TO CANCEL"))
                await conn.write(p.COLOR["yellow"] + p.encode("USERNAME: ") + p.COLOR["white"])
                username = (await conn.read_line(allow_case_toggle=True)).strip()
                if not username:
                    continue
                try:
                    async with loading(conn):
                        started = await client.cmail_start(username)
                except CyberSpaceError as e:
                    await conn.write(p.COLOR["light_red"])
                    await conn.write_line(f"ERROR: {e.message.upper()}"[:p.SCREEN_WIDTH])
                    await conn.write(p.COLOR["white"])
                    await asyncio.sleep(1.5)
                    continue
                convo_id = started.get("conversationId")
                other = started.get("otherUser") or {}
                other_name = other.get("username") or username
                if convo_id:
                    await cmail_conversation(conn, client, convo_id, me, other_name)
                try:
                    async with loading(conn):
                        displayed = await client.cmail_list() or []
                    seen_cmail_unread_counts.update(
                        (c.get("conversationId"), c.get("unreadCount") or 0)
                        for c in displayed if c.get("conversationId"))
                except CyberSpaceError:
                    pass
                page_index, selected = 0, 0
                continue
            if action == "OPEN" and page_convos:
                convo = page_convos[selected]
                convo_id = convo.get("conversationId")
                other = convo.get("otherUser") or {}
                other_name = other.get("displayName") or other.get("username") or "?"
                if convo_id:
                    await cmail_conversation(conn, client, convo_id, me, other_name)
                try:
                    async with loading(conn):
                        displayed = await client.cmail_list() or []
                    seen_cmail_unread_counts.update(
                        (c.get("conversationId"), c.get("unreadCount") or 0)
                        for c in displayed if c.get("conversationId"))
                except CyberSpaceError:
                    pass
                page_index = 0
    finally:
        stop_poll.set()
        poll_task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await poll_task


async def cmail_conversation(conn: TelnetConn, client: CyberSpaceClient,
                              conversation_id: str, me: dict, other_username: str):
    my_username = me.get("username", "")
    header_label = (other_username or "?").upper()

    message_blocks: list[list[tuple[list[tuple[bytes | None, str]], bool]]] = []
    scroll_offset = 0
    earliest_ts: int | None = None
    has_more_history = True
    seen_ids: set[str] = set()


    other_typing = False

    viewing_subscreen = False

    async def draw_footer():
        await conn.write(p.COLOR["yellow"])
        await conn.write(p.header_bar(f"C-MAIL: {header_label}"))
        await conn.write(p.COLOR["white"])
        if scroll_offset > 0:
            await conn.write(p.status_line(
                f"VIEWING HISTORY (-{scroll_offset}). /L=LATEST /D=DOWN"))
        elif other_typing:
            await conn.write(p.status_line(f"{header_label} IS TYPING..."))
        else:
            await conn.write(p.status_line("TYPE A MESSAGE + RETURN TO SEND."))
        await conn.write(p.status_line("/QUIT=BACK /HELP=COMMANDS"))
        await conn.write(p.COLOR["white"])
        await conn.write(p.rule())
        await conn.write(p.COLOR["white"])

    def visible_rows() -> list[tuple[list[tuple[bytes | None, str]], bool]]:
        if not message_blocks:
            return []
        end = max(0, min(len(message_blocks) - scroll_offset, len(message_blocks)))
        rows: list[tuple[list[tuple[bytes | None, str]], bool]] = []
        for block in message_blocks[:end]:
            rows.extend(block)
        return rows[-CMAIL_VISIBLE_LINES:]

    async def redraw(show_prompt: bool = True, flash: bool = False):
        await conn.busy_event.wait()
        if viewing_subscreen:
            return
        await conn.clear()
        rows = visible_rows()
        for _ in range(CMAIL_VISIBLE_LINES - len(rows)):
            await conn.write_line()
        for segments, _lowercase in rows:
            await conn.write(p.segment_line(segments))
        await draw_footer()
        if flash:
            async with loading(conn, "NEW MSG"):
                await asyncio.sleep(NEW_MESSAGE_FLASH_SEC)
        if show_prompt:
            await conn.write(p.input_prompt())

    def append_message(msg: dict, username: str, lowercase: bool = False):
        message_blocks.append(_build_cmail_message_rows(msg, username, lowercase))

    async def load_older_history() -> bool:
        nonlocal earliest_ts, has_more_history
        if not has_more_history or earliest_ts is None:
            return False
        try:
            page = await client.cmail_read(conversation_id, limit=20, before=earliest_ts)
        except CyberSpaceError:
            return False
        older = page.get("data") or []
        if not older:
            has_more_history = False
            return False
        new_blocks = []
        for msg in older:
            mid = _cmail_message_id(msg)
            if mid is not None:
                seen_ids.add(mid)
            earliest_ts = min(earliest_ts, msg.get("timestamp", earliest_ts))
            uname = msg.get("senderUsername") or other_username
            new_blocks.append(_build_cmail_message_rows(msg, uname))
        message_blocks[0:0] = new_blocks
        if len(older) < 20:
            has_more_history = False
        return True

    async def render_new(history: list[dict]) -> bool:
        added_any = False
        for msg in history:
            mid = _cmail_message_id(msg)
            if mid is not None and mid in seen_ids:
                continue
            if mid is not None:
                seen_ids.add(mid)
            uname = msg.get("senderUsername") or other_username
            append_message(msg, uname)
            added_any = True
        return added_any

    async def show_help_screen():
        nonlocal viewing_subscreen
        viewing_subscreen = True
        await conn.busy_event.wait()
        await conn.clear()
        await conn.write(p.COLOR["yellow"])
        await conn.write(p.header_bar("COMMAND LIST"))
        await conn.write(p.COLOR["white"])
        await conn.write(p.rule())
        await conn.write(p.COLOR["white"])
        commands = [
            ("/HELP", "THIS SCREEN"),
            ("/U", "SCROLL UP 1 MSG"),
            ("/D", "SCROLL DOWN 1 MSG"),
            ("/L", "JUMP TO LATEST"),
            ("/QUIT", "BACK TO C-MAIL LIST"),
            ("/FORTUNE", "RANDOM FORTUNE"),
            ("/8BALL <QUESTION>", "MAGIC 8-BALL"),
            ("/RAINBOW <MESSAGE>", "RAINBOW TEXT"),
            ("/SLOW <MESSAGE>", "S P A C E D   O U T"),
            ("/SLAP <@USER>", "SLAP SOMEONE"),
            ("/HI5 <@USER>", "HIGH-FIVE SOMEONE"),
            ("UP ARROW", "TOGGLE TYPE CASE"),
        ]
        for cmd, desc in commands:
            await conn.write(p.COLOR["yellow"])
            await conn.write(p.encode(f"{cmd:<12}"))
            await conn.write(p.COLOR["white"])
            await conn.write_line(desc)
        await conn.write(p.COLOR["white"])
        await conn.write(p.rule())
        await conn.write(p.status_line("PRESS ANY KEY TO GO BACK."))
        await conn.write(p.COLOR["white"])
        await conn.read_key()
        viewing_subscreen = False
        await redraw(show_prompt=False)


    await conn.clear()
    await conn.write(p.COLOR["yellow"])
    await conn.write(p.header_bar(f"C-MAIL: {header_label}"))
    await conn.write(p.COLOR["white"])
    try:
        async with loading(conn):
            initial = await client.cmail_read(conversation_id, limit=20)
    except CyberSpaceError as e:
        await conn.clear()
        await conn.write(p.COLOR["light_red"])
        for wline in p.wrap(f"COULDN'T LOAD C-MAIL: {e.message.upper()}"):
            await conn.write_line(wline)
        await conn.write(p.COLOR["white"])
        await conn.write_line()
        await conn.write(p.status_line("PRESS ANY KEY TO GO BACK."))
        await conn.read_key()
        return

    initial_data = initial.get("data") or []
    if initial_data:
        earliest_ts = min(m.get("timestamp", 0) for m in initial_data)
        if len(initial_data) < 20:
            has_more_history = False
    else:
        has_more_history = False
    await render_new(initial_data)
    try:
        await client.cmail_mark_read(conversation_id)
    except CyberSpaceError:
        pass

    prompt_active = False

    async def show_prompt():
        nonlocal prompt_active
        await conn.write(p.input_prompt())
        prompt_active = True

    await redraw(show_prompt=False)

    stop = asyncio.Event()

    async def poller():
        nonlocal other_typing
        while not stop.is_set():
            try:
                await client.ensure_fresh_token()
                page = await client.cmail_read(conversation_id, limit=20)
                had_new = await render_new(page.get("data") or [])
                if had_new:
                    try:
                        await client.cmail_mark_read(conversation_id)
                    except CyberSpaceError:
                        pass

                typing_changed = False
                try:
                    status = await client.cmail_typing_status(conversation_id)
                    tdata = status.get("data") or {}
                    stale_after = tdata.get("staleAfterMs") or 9000
                    since = tdata.get("since") or 0
                    now_ms = int(time.time() * 1000)
                    is_typing_now = bool(tdata.get("typing")) and (now_ms - since) < stale_after
                    typing_changed = is_typing_now != other_typing
                    other_typing = is_typing_now
                except CyberSpaceError:
                    pass

                if had_new or (typing_changed and scroll_offset == 0):
                    await redraw(show_prompt=prompt_active and not viewing_subscreen,
                                 flash=had_new)
            except CyberSpaceError:
                pass
            try:
                await asyncio.wait_for(stop.wait(), timeout=POLL_INTERVAL_SEC)
            except asyncio.TimeoutError:
                pass

    poll_task = asyncio.create_task(poller())
    try:
        while True:
            if not prompt_active:
                await show_prompt()
            line = (await conn.read_line(allow_case_toggle=True)).strip()
            prompt_active = False
            if not line:
                continue
            if line.upper() == "/QUIT":
                break
            if line.upper() == "/HELP":
                await show_help_screen()
                continue
            if line.upper() == "/U":
                if scroll_offset >= len(message_blocks) - 1:
                    await load_older_history()
                scroll_offset = min(scroll_offset + 1, max(0, len(message_blocks) - 1))
                await redraw(show_prompt=False)
                continue
            if line.upper() == "/D":
                scroll_offset = max(scroll_offset - 1, 0)
                await redraw(show_prompt=False)
                continue
            if line.upper() == "/L":
                scroll_offset = 0
                await redraw(show_prompt=False)
                continue


            force_plain_send = False
            if line.upper() == "/SLOW" or line.upper().startswith("/SLOW "):
                _, _, rest = line.partition(" ")
                rest = rest.strip()
                if not rest:
                    continue
                line = " ".join(rest)
                force_plain_send = True
            try:
                if line.startswith("/") and not force_plain_send:
                    command, _, rest = line.partition(" ")
                    sent_text = command.lower() + ((" " + rest) if rest else "")
                else:
                    sent_text = line
                result = await client.cmail_send(conversation_id, sent_text)
                sent_id = result.get("messageId") if isinstance(result, dict) else None

                msg = None
                if sent_text.startswith("/") and sent_id is not None:


                    for _ in range(3):
                        page = await client.cmail_read(conversation_id, limit=20)
                        for candidate in page.get("data") or []:
                            if _cmail_message_id(candidate) == sent_id:
                                msg = candidate
                                break
                        if msg is not None:
                            break
                        await asyncio.sleep(0.3)

                if msg is None:
                    msg = {"content": sent_text, "timestamp": int(time.time() * 1000)}
                    if sent_id is not None:
                        msg["id"] = sent_id

                mid = _cmail_message_id(msg)
                already_shown = mid is not None and mid in seen_ids
                if mid is not None:
                    seen_ids.add(mid)
                if not already_shown:
                    append_message(msg, my_username)
                scroll_offset = 0
                await redraw(show_prompt=False)
            except CyberSpaceError as e:
                for wline in p.wrap(f"ERROR: {e.message}"):
                    await conn.write_line(wline)
    finally:
        stop.set()
        poll_task.cancel()


        try:
            await client.cmail_typing_stop(conversation_id)
        except CyberSpaceError:
            pass


def _format_join_date(created_at) -> str | None:
    if not created_at or not isinstance(created_at, str):
        return None
    return created_at[:10] if len(created_at) >= 10 else created_at


def _first_present(d: dict, *keys: str):
    for key in keys:
        if key in d and d[key] is not None:
            return d[key]
    return None


async def show_profile(conn: TelnetConn, client: CyberSpaceClient, username: str,
                        me: dict | None = None):
    await conn.clear()
    await conn.write(p.COLOR["yellow"])
    await conn.write(p.header_bar("USER LOOKUP"))
    await conn.write(p.COLOR["white"])

    while True:
        try:
            async with loading(conn):
                profile = await client.users_get_profile(username)
        except CyberSpaceError as e:
            await conn.write(p.COLOR["light_red"])
            for wline in p.wrap(f"COULDN'T LOAD PROFILE: {e.message.upper()}"):
                await conn.write_line(wline)
            await conn.write(p.COLOR["white"])
            await conn.write_line()
            await conn.write(p.status_line("PRESS ANY KEY TO GO BACK."))
            await conn.read_key()
            return

        uname = profile.get("username") or username
        display_name = profile.get("displayName")
        bio = profile.get("bio")
        follower_count = _first_present(
            profile, "followerCount", "followersCount", "follower_count", "followers_count")
        following_count = _first_present(
            profile, "followingCount", "follows_count", "following_count")
        post_count = _first_present(
            profile, "postCount", "postsCount", "entryCount", "entriesCount", "post_count")
        website_name = profile.get("websiteName")
        website_url = profile.get("websiteUrl")
        location_name = profile.get("locationName")
        joined = _format_join_date(profile.get("createdAt"))
        is_self = bool(me) and me.get("username", "").lower() == uname.lower()

        meta_line = f"@{uname}"
        if display_name:
            meta_line += f" ({display_name})"
        meta_color = p.COLOR["yellow"] if is_self else p.COLOR["light_green"]

        parts: list[str] = []
        if bio:
            parts.append(bio)
            parts.append("")
        stats_bits = []
        if follower_count is not None:
            stats_bits.append(f"{follower_count} FOLLOWERS")
        if following_count is not None:
            stats_bits.append(f"{following_count} FOLLOWING")
        if post_count is not None:
            stats_bits.append(f"{post_count} POSTS")
        if stats_bits:
            parts.append(" / ".join(stats_bits))
        if location_name:
            parts.append(f"LOCATION: {location_name}")
        if website_name or website_url:
            parts.append(f"WEB: {website_name or website_url}")
        if joined:
            parts.append(f"MEMBER SINCE: {joined}")
        content = "\n".join(parts) if parts else "(NO BIO OR DETAILS.)"

        if is_self:
            action_keys = {"P": "POSTS", "Q": "BACK"}
        else:
            action_keys = {"K": "POKE", "P": "POSTS", "Q": "BACK"}
        action = await paginated_reader(conn, "USER LOOKUP", meta_line, content,
                                         action_keys, meta_color=meta_color)

        if action is None or action == "Q":
            return

        if action == "P":
            await show_user_posts(conn, client, uname, me=me)
            await conn.clear()
            await conn.write(p.COLOR["yellow"])
            await conn.write(p.header_bar("USER LOOKUP"))
            await conn.write(p.COLOR["white"])
            continue

        if action == "K":
            await conn.clear()
            await conn.write(p.COLOR["yellow"])
            await conn.write(p.header_bar(f"POKE @{uname}"))
            await conn.write(p.COLOR["white"])
            try:
                async with loading(conn, "POKING"):
                    await client.users_poke(uname)
                status = client.poke_quota_estimate()
                await conn.write(p.COLOR["light_green"])
                await conn.write_line(f"POKED @{uname}!")
                await conn.write(p.COLOR["white"])
                for wline in p.wrap(
                    f"{status['remaining_hour']}/HR, {status['remaining_today']}/DAY "
                    "LEFT THIS SESSION (EST., SHARED ACROSS EVERYONE YOU POKE)."
                ):
                    await conn.write_line(wline)
            except CyberSpaceError as e:
                await conn.write(p.COLOR["light_red"])
                for wline in p.wrap(f"COULDN'T POKE: {e.message.upper()}"):
                    await conn.write_line(wline)
            await conn.write(p.COLOR["white"])
            await conn.write_line()
            await conn.write(p.status_line("PRESS ANY KEY TO CONTINUE."))
            await conn.read_key()
            await conn.clear()
            await conn.write(p.COLOR["yellow"])
            await conn.write(p.header_bar("USER LOOKUP"))
            await conn.write(p.COLOR["white"])
            continue


def _draw_user_posts_page(username: str, page_index: int, page: dict,
                           entries: list[dict], selected: int) -> bytes:
    out = bytearray()
    out += p.CLR
    out += p.COLOR["yellow"]
    out += p.header_bar(f"@{username}'S POSTS -- PAGE {page_index + 1}", width=FEED_ROW_WIDTH)
    out += p.COLOR["white"]


    out += _new_items_alert_row(0, "POST", width=FEED_ROW_WIDTH)
    if not entries:
        out += p.status_line("NO POSTS YET.", width=FEED_ROW_WIDTH)
    for i, entry in enumerate(entries, start=1):
        out += _feed_row_bytes(i, entry, (i - 1) == selected, set(), None)
    out += p.COLOR["white"]
    out += p.rule(width=FEED_ROW_WIDTH)
    out += p.COLOR["white"]
    hint_parts = ["W/S=MOVE", "RETURN=READ"]
    if page.get("cursor"):
        hint_parts.append("N=NEXT")
    if page_index > 0:
        hint_parts.append("P=PREV")
    hint_parts.append("Q=BACK")
    out += p.status_line(" ".join(hint_parts), width=FEED_ROW_WIDTH)
    return bytes(out)


async def show_user_posts(conn: TelnetConn, client: CyberSpaceClient, username: str,
                           me: dict | None = None):
    pages: list[dict] = []

    async def load_page(cursor: str | None) -> dict:
        result = await client.users_get_posts(username, limit=MAX_FEED_ROWS, cursor=cursor)
        return {"entries": result.get("data") or [], "cursor": result.get("cursor")}

    await conn.clear()
    await conn.write(p.COLOR["yellow"])
    await conn.write(p.header_bar(f"@{username}'S POSTS"))
    await conn.write(p.COLOR["white"])
    try:
        async with loading(conn):
            pages.append(await load_page(None))
    except CyberSpaceError as e:
        await conn.write(p.COLOR["light_red"])
        for wline in p.wrap(f"COULDN'T LOAD POSTS: {e.message.upper()}"):
            await conn.write_line(wline)
        await conn.write(p.COLOR["white"])
        await conn.write_line()
        await conn.write(p.status_line("PRESS ANY KEY TO GO BACK."))
        await conn.read_key()
        return

    page_index = 0
    selected = 0
    empty_viewed_ids: set[str] = set()
    while True:
        page = pages[page_index]
        entries = page["entries"][:MAX_FEED_ROWS]
        selected = max(0, min(selected, len(entries) - 1)) if entries else 0

        await conn.write(_draw_user_posts_page(username, page_index, page, entries, selected))

        action = await _wait_for_feed_action(conn, entries, selected, empty_viewed_ids)

        if action == "QUIT":
            return
        if action == "UP":
            selected -= 1
            continue
        if action == "DOWN":
            selected += 1
            continue
        if action == "NEXT":
            if page.get("cursor"):
                if page_index + 1 >= len(pages):
                    try:
                        async with loading(conn):
                            pages.append(await load_page(page["cursor"]))
                    except CyberSpaceError as e:
                        await conn.write(p.COLOR["light_red"])
                        await conn.write_line(f"ERROR: {e.message.upper()}"[:p.SCREEN_WIDTH])
                        await conn.write(p.COLOR["white"])
                        await asyncio.sleep(1)
                        continue
                page_index += 1
                selected = 0
            continue
        if action == "PREV":
            if page_index > 0:
                page_index -= 1
                selected = 0
            continue
        if action == "OPEN" and entries:
            await read_entry(conn, client, entries[selected], me=me)


async def user_lookup(conn: TelnetConn, client: CyberSpaceClient, me: dict):
    await conn.clear()
    await conn.write(p.COLOR["yellow"])
    await conn.write(p.header_bar("USER LOOKUP"))
    await conn.write(p.COLOR["white"])
    await conn.write(p.status_line("WHO DO YOU WANT TO LOOK UP? BLANK=BACK"))
    await conn.write(p.COLOR["yellow"] + p.encode("USERNAME: ") + p.COLOR["white"])
    username = (await conn.read_line(allow_case_toggle=True)).strip()
    if not username:
        return
    await show_profile(conn, client, username, me=me)


async def saved_login_screen(conn: TelnetConn):
    state = _load_remembered_state()
    emails = sorted(state["logins"].keys())
    last = state.get("last")

    await conn.clear()
    await conn.write(p.COLOR["yellow"])
    await conn.write(p.header_bar("SAVED LOGIN"))
    await conn.write(p.COLOR["white"])

    if not emails:
        await conn.write(p.status_line("NOTHING IS REMEMBERED ON THIS BRIDGE."))
        await conn.write_line()
        await conn.write(p.status_line("PRESS ANY KEY TO GO BACK."))
        await conn.read_key()
        return

    await conn.write(p.status_line("GREEN = SIGNS IN AUTOMATICALLY."))
    await conn.write(p.status_line("#=FORGET THAT ONE, A=FORGET ALL, Q=BACK."))
    await conn.write(p.COLOR["white"])
    await conn.write(p.rule())
    for i, email in enumerate(emails, start=1):
        is_last = email == last
        await conn.write(p.COLOR["yellow"])
        await conn.write(p.encode(f"{i:>2} "))
        await conn.write(p.COLOR["light_green"] if is_last else p.COLOR["white"])
        await conn.write_line(email[:p.SCREEN_WIDTH - 3])
    await conn.write(p.COLOR["white"])
    await conn.write(p.rule())
    await conn.write(p.input_prompt("#/A/Q"))
    choice = (await conn.read_line(allow_case_toggle=True)).strip().upper()

    if choice == "A":
        for email in emails:
            _forget_login(email)
        await conn.write(p.COLOR["light_green"])
        await conn.write_line("ALL SAVED LOGINS FORGOTTEN.")
        await conn.write(p.COLOR["white"])
        await asyncio.sleep(1)
        return
    try:
        idx = int(choice)
    except ValueError:
        return
    if 1 <= idx <= len(emails):
        target = emails[idx - 1]
        _forget_login(target)
        await conn.write(p.COLOR["light_green"])
        await conn.write_line(f"FORGOT {target.upper()}."[:p.SCREEN_WIDTH])
        await conn.write(p.COLOR["white"])
        await asyncio.sleep(1)


MAX_NOTIF_ROWS = 14


NOTIF_TYPE_LABELS = {
    "bookmark": "BOOKMARKED YOUR POST",
    "reply": "REPLIED TO YOUR ENTRY",
    "thread_reply": "NEW REPLY IN A WATCHED THREAD",
    "new_follower": "FOLLOWED YOU",
    "unfollowed": "UNFOLLOWED YOU",
    "new_post_following": "POSTED A NEW ENTRY",
    "new_post_friend": "POSTED A NEW ENTRY (MUTUAL)",
    "poke": "POKED YOU",
    "chat_mention": "MENTIONED YOU IN CHAT",
    "post_mention": "MENTIONED YOU IN AN ENTRY",
    "reply_mention": "MENTIONED YOU IN A REPLY",
    "dm_message": "SENT YOU A C-MAIL",
    "guild_new_thread": "NEW GUILD THREAD",
    "supporter_granted": "GRANTED SUPPORTER STATUS",
    "supporter_removed": "SUPPORTER STATUS REMOVED",
    "hacker_granted": "GRANTED HACKER STATUS",
    "hacker_removed": "HACKER STATUS REMOVED",
    "image_permission_granted": "IMAGE PERMISSION GRANTED",
    "image_permission_removed": "IMAGE PERMISSION REMOVED",
    "attachment_permission_granted": "ATTACHMENT PERMISSION GRANTED",
    "attachment_permission_removed": "ATTACHMENT PERMISSION REMOVED",
    "system_ban": "SYSTEM NOTICE",
}


def _notif_line(n: dict) -> str:
    actor = n.get("actorUsername")
    raw_type = n.get("type") or "?"
    label = NOTIF_TYPE_LABELS.get(raw_type, raw_type.upper().replace("_", " "))
    meta = n.get("metadata") or {}
    where = None
    if raw_type == "chat_mention":
        where = meta.get("roomName") or meta.get("room")
    elif raw_type in ("post_mention", "reply_mention", "reply", "thread_reply"):
        where = meta.get("postTitle") or meta.get("title")
    if raw_type == "chat_mention" and actor and where:


        return f"@{actor} MENTIONED YOU IN {where}"
    line = f"@{actor} {label}" if actor else label
    if where:
        line += f" IN {where}"
    return line


NOTIF_ROW_WIDTH = 39


NOTIF_TITLE_WIDTH = NOTIF_ROW_WIDTH - 3


def _notif_marquee_text(n: dict) -> str:
    return p.petscii_safe(_notif_line(n))


def _notif_marqueeable(n: dict) -> bool:
    return len(_notif_marquee_text(n)) > NOTIF_TITLE_WIDTH


def _notif_row_bytes(i: int, n: dict, highlighted: bool, window: str | None = None) -> bytes:
    full_text = _notif_marquee_text(n)
    marqueeable = len(full_text) > NOTIF_TITLE_WIDTH
    shown = window if window is not None else full_text[:NOTIF_TITLE_WIDTH]
    unread = not n.get("read")
    out = bytearray()
    if highlighted:
        out += p.RVS_ON
    out += p.COLOR["yellow"]
    out += p.encode(f"{i:>2} ")
    if highlighted:
        out += p.COLOR["white"]
    elif unread:
        out += p.COLOR["light_green"]
    else:
        out += p.COLOR["white"]
    out += p.encode(f"{shown:<{NOTIF_TITLE_WIDTH}}"[:NOTIF_TITLE_WIDTH])
    if highlighted:
        out += p.RVS_OFF
    out += p.COLOR["white"] + p.RETURN
    return bytes(out)


def _draw_notif_page(page_index: int, page: dict, items: list[dict], selected: int,
                      window: str | None = None, new_count: int = 0) -> bytes:
    out = bytearray()
    out += p.CLR
    out += p.COLOR["yellow"]
    out += p.header_bar(f"NOTIFICATIONS -- PAGE {page_index + 1}", width=NOTIF_ROW_WIDTH)
    out += p.COLOR["white"]
    out += _new_items_alert_row(new_count, "NOTIFICATION", width=NOTIF_ROW_WIDTH)
    if not items:
        out += p.status_line("NOTHING HERE.", width=NOTIF_ROW_WIDTH)
    for i, n in enumerate(items, start=1):
        row_window = window if (i - 1) == selected else None
        out += _notif_row_bytes(i, n, (i - 1) == selected, row_window)
    out += p.COLOR["white"]
    out += p.rule(width=NOTIF_ROW_WIDTH)
    out += p.COLOR["white"]

    hint_parts = ["W/S=MOVE", "RETURN=OPEN", "A=MARK ALL"]
    if page.get("cursor"):
        hint_parts.append("N=NEXT")
    if page_index > 0:
        hint_parts.append("P=PREV")
    hint_parts.append("Q=BACK")
    out += p.status_line(" ".join(hint_parts), width=NOTIF_ROW_WIDTH)
    return bytes(out)


async def _redraw_notif_row(conn: TelnetConn, i: int, n: dict, window: str):
    await conn.write(p.HOME)
    await conn.write(p.CRSR_DOWN * (i + 1))
    await conn.write(_notif_row_bytes(i, n, True, window))


async def _wait_for_notif_action(conn: TelnetConn, items: list[dict], selected: int,
                                  refresh_event: asyncio.Event | None = None) -> str:
    offset = 0
    key_task = asyncio.create_task(conn.read_key())
    try:
        while True:
            timer_task = asyncio.create_task(asyncio.sleep(MARQUEE_TICK_SEC))
            wait_set = {key_task, timer_task}
            refresh_task = asyncio.create_task(refresh_event.wait()) if refresh_event else None
            if refresh_task is not None:
                wait_set.add(refresh_task)
            done, _ = await asyncio.wait(wait_set, return_when=asyncio.FIRST_COMPLETED)

            if refresh_task is not None and refresh_task in done:
                timer_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await timer_task
                refresh_event.clear()
                return "NEW_AVAILABLE"
            if refresh_task is not None and not refresh_task.done():
                refresh_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await refresh_task

            if key_task not in done:
                timer_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await timer_task
                if items and 0 <= selected < len(items):
                    n = items[selected]
                    if not n.get("read") and _notif_marqueeable(n):
                        offset += 1
                        window = _marquee_window(_notif_marquee_text(n), NOTIF_TITLE_WIDTH, offset)
                        await _redraw_notif_row(conn, selected + 1, n, window)
                continue

            timer_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await timer_task
            byte = key_task.result()
            if byte == 0x0D:
                return "OPEN"
            ch = chr(byte).upper() if 32 <= byte < 127 else ""
            if ch == "W":
                return "UP"
            if ch == "S":
                return "DOWN"
            if ch == "A":
                return "MARK_ALL"
            if ch == "N":
                return "NEXT"
            if ch == "P":
                return "PREV"
            if ch == "R":
                return "PULL_NEW"
            if ch == "Q":
                return "QUIT"

            key_task = asyncio.create_task(conn.read_key())
    finally:
        if not key_task.done():
            key_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await key_task


async def _notif_show_info(conn: TelnetConn, n: dict, extra: str | None = None):
    await conn.clear()
    await conn.write(p.COLOR["yellow"])
    await conn.write(p.header_bar("NOTIFICATION"))
    await conn.write(p.COLOR["white"])
    await conn.write_line(_notif_line(n))
    reason = (n.get("metadata") or {}).get("reason")
    if reason:
        await conn.write_line()
        for wline in p.wrap(str(reason).upper()):
            await conn.write_line(wline)
    if extra:
        await conn.write_line()
        await conn.write(p.COLOR["light_red"])
        for wline in p.wrap(extra):
            await conn.write_line(wline)
        await conn.write(p.COLOR["white"])
    await conn.write_line()
    await conn.write(p.status_line("NOTHING TO JUMP TO. ANY KEY=BACK."))
    await conn.read_key()


def _msg_mentions(msg: dict, username: str) -> bool:
    if not username or msg.get("username") == username:
        return False
    text = " ".join(
        str(msg.get(field) or "")
        for field in ("content", "fortuneText", "eightballAnswer")
    )
    if not text:
        return False
    return re.search(rf"@{re.escape(username)}\b", text, re.IGNORECASE) is not None


MENTION_SEARCH_PAGE_SIZE = 50
MENTION_SEARCH_MAX_PAGES = 20


MENTION_SEARCH_WINDOW_MS = 24 * 60 * 60 * 1000


def _notif_created_ms(n: dict) -> int | None:
    raw = n.get("createdAt") or n.get("timestamp") or n.get("created_at")
    if raw is None:
        return None
    if isinstance(raw, (int, float)):


        return int(raw * 1000) if raw < 4_000_000_000_000 else int(raw)
    try:
        return int(datetime.fromisoformat(str(raw).replace("Z", "+00:00")).timestamp() * 1000)
    except (ValueError, TypeError):
        return None


async def _chat_mention_preview_and_confirm(conn: TelnetConn, client: CyberSpaceClient,
                                             room_id: str, room_name: str, n: dict,
                                             me: dict | None) -> bool:
    meta = n.get("metadata") or {}
    actor = n.get("actorUsername") or meta.get("username") or "?"
    content = meta.get("content") or meta.get("message") or meta.get("text")
    preview = (actor, str(content)) if content else None

    if preview is None:
        msg_id = meta.get("messageId") or meta.get("circMessageId")
        found = None
        found_any = None
        notif_ts_ms = _notif_created_ms(n)
        await conn.clear()

        anchor_ms = (notif_ts_ms + 5_000) if notif_ts_ms is not None else int(time.time() * 1000)
        cutoff_ms = anchor_ms - MENTION_SEARCH_WINDOW_MS
        my_username = me.get("username") if me else None
        try:
            before_ts = anchor_ms if notif_ts_ms is not None else None
            for _ in range(MENTION_SEARCH_MAX_PAGES):
                async with loading(conn, "LOADING MESSAGE"):
                    history = await client.circ_read_room(
                        room_id, limit=MENTION_SEARCH_PAGE_SIZE, before=before_ts)
                msgs = history.get("data") or []
                if not msgs:
                    break
                in_window = [m for m in msgs
                             if m.get("timestamp") is None
                             or cutoff_ms <= m.get("timestamp") <= anchor_ms]
                if msg_id:
                    found = next(
                        (m for m in in_window
                         if (m.get("id") or m.get("messageId")) == msg_id), None)
                if found is None and my_username:
                    for m in in_window:
                        if _msg_mentions(m, my_username):
                            found_any = m
                            if actor != "?" and m.get("username") == actor:
                                found = m
                if found is not None:
                    break
                timestamps = [m.get("timestamp") for m in msgs if m.get("timestamp") is not None]
                if not timestamps:
                    break
                oldest_in_page = min(timestamps)
                if oldest_in_page < cutoff_ms:
                    break
                before_ts = oldest_in_page
            if found is None:
                found = found_any
            if found is not None:
                preview = (found.get("username") or actor, str(found.get("content") or ""))
        except CyberSpaceError:
            pass

    await conn.clear()
    await conn.write(p.COLOR["yellow"])
    await conn.write(p.header_bar("CHAT MENTION"))
    await conn.write(p.COLOR["white"])
    await conn.write_line(f"ROOM: {room_name}".upper())
    await conn.write_line()
    if preview:
        who, text = preview
        for wline in p.wrap(f"@{who}: {text}"):
            await conn.write_line(wline)
    else:
        await conn.write(p.COLOR["light_red"])
        for wline in p.wrap("COULDN'T FIND THE SPECIFIC MESSAGE -- IT MAY HAVE "
                             "SCROLLED OUT OF RECENT HISTORY."):
            await conn.write_line(wline)
        await conn.write(p.COLOR["white"])
    await conn.write_line()
    await conn.write(p.status_line("G=GO TO ROOM, ANY OTHER=DISMISS"))
    byte = await conn.read_key()
    return 32 <= byte < 127 and chr(byte).upper() == "G"


async def _open_notification(conn: TelnetConn, client: CyberSpaceClient, n: dict,
                              me: dict | None):
    raw_type = n.get("type") or ""
    meta = n.get("metadata") or {}
    actor = n.get("actorUsername")
    target_id = n.get("targetId")


    if raw_type in ("reply", "thread_reply", "reply_mention",
                    "post_mention", "bookmark", "new_post_following", "new_post_friend"):
        reply_id = meta.get("replyId")
        if reply_id:
            try:
                async with loading(conn, "LOADING REPLY"):
                    reply = await client.replies_get(reply_id)
                    parent = None
                    parent_id = _reply_parent_id(reply)
                    if parent_id:
                        try:
                            parent = await client.replies_get(parent_id)
                        except CyberSpaceError:
                            parent = None
                post_id = reply.get("postId") or target_id
                await read_reply(conn, client, post_id, reply, parent=parent, me=me)
                return
            except CyberSpaceError as e:
                await _notif_show_info(conn, n, extra=f"COULDN'T LOAD THAT REPLY: {e.message.upper()}")
                return
        if target_id:
            try:
                async with loading(conn, "LOADING ENTRY"):
                    entry = await client.entries_get(target_id)
                await read_entry(conn, client, entry, me=me)
                return
            except CyberSpaceError as e:
                await _notif_show_info(conn, n, extra=f"COULDN'T LOAD THAT ENTRY: {e.message.upper()}")
                return
        await _notif_show_info(conn, n)
        return

    if raw_type == "chat_mention":


        candidates = [
            meta.get("roomId"), meta.get("room"), meta.get("circRoomId"),
            meta.get("roomSlug"), meta.get("roomName"), target_id,
        ]
        candidates = [c for c in candidates if c]
        if candidates:
            resolved_id = resolved_name = candidates[0]
            try:
                async with loading(conn, "FINDING ROOM"):
                    rooms = await client.circ_list_rooms()
                for candidate in candidates:
                    matched = False
                    for r in rooms or []:
                        rid = r.get("id") or r.get("slug")
                        rname = r.get("name") or r.get("slug")
                        if candidate in (rid, rname):
                            resolved_id = rid or candidate
                            resolved_name = rname or candidate
                            matched = True
                            break
                    if matched:
                        break
            except CyberSpaceError:
                pass
            go = await _chat_mention_preview_and_confirm(conn, client, resolved_id,
                                                           resolved_name, n, me)
            if go:
                await chat_room(conn, client, resolved_id, me or {}, room_name=resolved_name)
            return
        await _notif_show_info(
            conn, n, extra="THE ROOM THIS MENTION CAME FROM ISN'T "
                           "INCLUDED ON THE NOTIFICATION -- TRY CHAT ROOMS "
                           "FROM THE MAIN MENU.")
        return

    if raw_type == "dm_message":
        convo_id = meta.get("conversationId") or target_id
        if convo_id:
            await cmail_conversation(conn, client, convo_id, me or {}, actor or "?")
            return
        await _notif_show_info(conn, n)
        return

    if raw_type in ("poke", "new_follower", "unfollowed") and actor:
        await show_profile(conn, client, actor, me=me)
        return


    await _notif_show_info(conn, n)


async def notifications_screen(conn: TelnetConn, client: CyberSpaceClient,
                                seen_notif_ids: set[str],
                                me: dict | None = None):
    pages: list[dict] = []

    async def load_page(cursor: str | None) -> dict:
        result = await client.notifications_list(limit=MAX_NOTIF_ROWS, cursor=cursor)
        return {"items": result.get("data") or [], "cursor": result.get("cursor")}

    await conn.clear()
    await conn.write(p.COLOR["yellow"])
    await conn.write(p.header_bar("NOTIFICATIONS"))
    await conn.write(p.COLOR["white"])
    try:
        async with loading(conn):
            pages.append(await load_page(None))
    except CyberSpaceError as e:
        await conn.clear()
        await conn.write(p.COLOR["light_red"])
        for wline in p.wrap(f"COULDN'T LOAD NOTIFICATIONS: {e.message.upper()}"):
            await conn.write_line(wline)
        await conn.write(p.COLOR["white"])
        await conn.write_line()
        await conn.write(p.status_line("PRESS ANY KEY TO GO BACK."))
        await conn.read_key()
        return


    pending_new: list[dict] = []
    pending_new_ids: set[str] = set()
    new_notif_event = asyncio.Event()
    stop_poll = asyncio.Event()

    def _new_notifications(fresh_items: list[dict]) -> list[dict]:
        existing_ids = {n.get("id") for n in pages[0]["items"]}
        return [n for n in fresh_items
                if n.get("id") not in existing_ids and n.get("id") not in pending_new_ids]

    async def poller():
        while not stop_poll.is_set():
            try:
                await client.ensure_fresh_token()
                fresh = await load_page(None)
                newly_found = _new_notifications(fresh["items"])
                if newly_found:
                    pending_new[0:0] = newly_found
                    pending_new_ids.update(n.get("id") for n in newly_found)
                    new_notif_event.set()
            except CyberSpaceError:
                pass
            except Exception as e:


                print(f"[!] notifications poller: {e!r} -- will retry")
            try:
                await asyncio.wait_for(stop_poll.wait(), timeout=LIST_POLL_INTERVAL_SEC)
            except asyncio.TimeoutError:
                pass

    poll_task = asyncio.create_task(poller())
    try:
        page_index = 0
        selected = 0
        while True:
            page = pages[page_index]
            items = page["items"][:MAX_NOTIF_ROWS]
            selected = max(0, min(selected, len(items) - 1)) if items else 0

            new_count = len(pending_new) if page_index == 0 else 0
            await conn.write(_draw_notif_page(page_index, page, items, selected,
                                               new_count=new_count))

            refresh_event = new_notif_event if page_index == 0 else None
            action = await _wait_for_notif_action(conn, items, selected,
                                                   refresh_event=refresh_event)

            if action == "QUIT":
                return
            if action == "NEW_AVAILABLE":
                continue
            if action == "PULL_NEW":
                if pending_new:
                    prev_id = items[selected].get("id") if items else None
                    page["items"][0:0] = pending_new
                    pending_new.clear()
                    pending_new_ids.clear()
                    selected = 0
                    if prev_id is not None:
                        for idx, n in enumerate(page["items"][:MAX_NOTIF_ROWS]):
                            if n.get("id") == prev_id:
                                selected = idx
                                break
                continue
            if action == "UP":
                selected -= 1
                continue
            if action == "DOWN":
                selected += 1
                continue
            if action == "MARK_ALL":
                try:
                    async with loading(conn):
                        await client.notifications_mark_all_read()
                    for pg in pages:
                        for n in pg["items"]:
                            n["read"] = True
                except CyberSpaceError as e:
                    await conn.write(p.COLOR["light_red"])
                    await conn.write_line(f"ERROR: {e.message.upper()}"[:p.SCREEN_WIDTH])
                    await conn.write(p.COLOR["white"])
                    await asyncio.sleep(1)
                continue
            if action == "NEXT":
                if page.get("cursor"):
                    if page_index + 1 >= len(pages):
                        try:
                            async with loading(conn):
                                pages.append(await load_page(page["cursor"]))
                        except CyberSpaceError as e:
                            await conn.write(p.COLOR["light_red"])
                            await conn.write_line(f"ERROR: {e.message.upper()}"[:p.SCREEN_WIDTH])
                            await conn.write(p.COLOR["white"])
                            await asyncio.sleep(1)
                            continue
                    page_index += 1
                    selected = 0
                continue
            if action == "PREV":
                if page_index > 0:
                    page_index -= 1
                    selected = 0
                continue
            if action == "OPEN" and items:
                n = items[selected]
                nid = n.get("id")
                if nid and not n.get("read"):
                    try:
                        await client.notifications_mark_read(nid)
                        n["read"] = True
                    except CyberSpaceError:
                        pass
                await _open_notification(conn, client, n, me)
    finally:
        stop_poll.set()
        poll_task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await poll_task


        seen_notif_ids.update(
            n.get("id") for pg in pages for n in pg["items"] if n.get("id") is not None
        )


async def handle_client(reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
    peer = writer.get_extra_info("peername")
    print(f"[+] connection from {peer}")
    conn = TelnetConn(reader, writer)
    async with aiohttp.ClientSession() as http:
        client = CyberSpaceClient(http)
        try:


            await conn.write(p.UPPERCASE_CHARSET)


            await conn.write(p.LOWERCASE_CHARSET)
            await show_banner(conn)
            me = await do_login(conn, client)


            await conn.clear()
            await conn.write(p.UPPERCASE_CHARSET)


            seen_notif_ids: set[str] = set()
            seen_cmail_unread_counts: dict[str, int] = {}
            while True:
                choice = await main_menu(conn, client, me, seen_notif_ids, seen_cmail_unread_counts)
                if choice == "C":
                    while True:
                        picked = await show_room_selector(conn, client)
                        if picked is None:
                            break
                        room_id, room_name = picked
                        await chat_room(conn, client, room_id, me, room_name=room_name)
                elif choice == "F":
                    await feed_viewer(conn, client, me=me)
                elif choice == "W":
                    await write_post(conn, client, me)
                elif choice == "M":
                    await cmail_inbox(conn, client, me, seen_cmail_unread_counts)
                elif choice == "N":
                    await notifications_screen(conn, client, seen_notif_ids, me=me)
                elif choice == "U":
                    await user_lookup(conn, client, me)
                elif choice == "R":
                    await saved_login_screen(conn)
                elif choice == "I":
                    await show_credits(conn)
                elif choice == "Q":
                    await conn.clear()
                    await conn.write(p.COLOR["light_green"])
                    await conn.write(p.header_bar("SEE YOU SOON!"))
                    await conn.write(p.COLOR["white"])
                    await conn.write(p.status_line("THANKS FOR VISITING CYBERSPACE."))
                    break
                else:
                    await conn.write(p.COLOR["light_red"])
                    await conn.write_line(f"SORRY, '{choice}' ISN'T ON THE MENU -- TRY AGAIN.")
                    await conn.write(p.COLOR["white"])
                    await asyncio.sleep(1)
        except (ConnectionError, asyncio.IncompleteReadError):
            pass
        finally:
            writer.close()
            print(f"[-] disconnected {peer}")


async def run(port: int):
    server = await asyncio.start_server(handle_client, host="0.0.0.0", port=port)
    print(f"CyberSpace BBS bridge listening on :{port} -- point your C64 terminal client here")
    async with server:
        await server.serve_forever()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=6400)
    args = parser.parse_args()
    asyncio.run(run(args.port))
