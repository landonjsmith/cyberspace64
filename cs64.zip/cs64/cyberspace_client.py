from __future__ import annotations

import asyncio
import collections
import time
import aiohttp

BASE_URL = "https://api.cyberspace.online"


class CyberSpaceError(Exception):
    def __init__(self, code: str, message: str, status: int):
        super().__init__(f"{code}: {message}")
        self.code = code
        self.message = message
        self.status = status


class _RateGate:

    def __init__(self):
        self._calls: dict[str, collections.deque] = {}

    async def wait_turn(self, key: str, limit_per_min: int):
        dq = self._calls.setdefault(key, collections.deque())
        while True:
            now = time.monotonic()
            while dq and now - dq[0] > 60:
                dq.popleft()
            if len(dq) < limit_per_min:
                dq.append(now)
                return
            await asyncio.sleep(60 - (now - dq[0]) + 0.05)


class CyberSpaceClient:
    def __init__(self, session: aiohttp.ClientSession):
        self.session = session
        self.id_token: str | None = None
        self.refresh_token: str | None = None
        self._token_fetched_at: float = 0.0
        self._rate_gate = _RateGate()


        self._send_times: collections.deque = collections.deque()


        self._cmail_send_times: collections.deque = collections.deque()


        self._poke_times: collections.deque = collections.deque()


    async def login(self, email: str, password: str) -> dict:
        data = await self._request(
            "POST", "/v1/auth/login",
            json={"email": email, "password": password},
            auth=False,
        )
        self.id_token = data["idToken"]
        self.refresh_token = data["refreshToken"]
        self._token_fetched_at = time.monotonic()
        return data

    async def refresh(self) -> None:
        data = await self._request(
            "POST", "/v1/auth/refresh",
            json={"refreshToken": self.refresh_token},
            auth=False,
        )
        self.id_token = data["idToken"]
        self._token_fetched_at = time.monotonic()

    async def ensure_fresh_token(self) -> None:

        if time.monotonic() - self._token_fetched_at > 45 * 60:
            await self.refresh()

    async def me(self) -> dict:
        return await self._request("GET", "/v1/users/me")


    async def circ_list_rooms(self) -> list[dict]:

        await self._rate_gate.wait_turn("circ_list_rooms", 25)
        return await self._request("GET", "/v1/circ")

    async def circ_read_room(self, room_id: str, limit: int = 50,
                              before: int | None = None) -> dict:


        await self._rate_gate.wait_turn("circ_read_room", 38)
        params = {"limit": str(limit)}
        if before is not None:
            params["before"] = str(before)
        return await self._request("GET", f"/v1/circ/{room_id}", params=params,
                                    return_full=True)

    async def circ_send(self, room_id: str, content: str) -> dict:


        try:
            result = await self._request("POST", f"/v1/circ/{room_id}",
                                          json={"content": content})
        except CyberSpaceError as e:
            if e.status == 429:


                now = time.time()
                dq = self._send_times
                while len(dq) < self.CIRC_SEND_DAILY_CAP:
                    dq.append(now)
            raise
        self._send_times.append(time.time())
        return result

    CIRC_SEND_DAILY_CAP = 300
    CIRC_SEND_WINDOW_SECONDS = 24 * 60 * 60

    def circ_send_quota_estimate(self) -> dict:
        now = time.time()
        dq = self._send_times
        while dq and now - dq[0] > self.CIRC_SEND_WINDOW_SECONDS:
            dq.popleft()
        used = len(dq)
        remaining = max(0, self.CIRC_SEND_DAILY_CAP - used)
        seconds_until_next_slot = 0.0
        if used >= self.CIRC_SEND_DAILY_CAP:
            seconds_until_next_slot = self.CIRC_SEND_WINDOW_SECONDS - (now - dq[0])
        return {
            "used": used,
            "cap": self.CIRC_SEND_DAILY_CAP,
            "remaining": remaining,
            "seconds_until_next_slot": max(0.0, seconds_until_next_slot),
        }

    async def circ_presence_announce(self, room_id: str,
                                      last_activity_ms: int | None = None) -> dict:


        await self._rate_gate.wait_turn(f"circ_presence:{room_id}", 12)
        await self._rate_gate.wait_turn("circ_presence:overall", 75)
        body = {}
        if last_activity_ms is not None:
            body["lastActivity"] = last_activity_ms
        return await self._request("POST", f"/v1/circ/{room_id}/presence",
                                    json=body)

    async def circ_presence_leave(self, room_id: str) -> dict:
        return await self._request("DELETE", f"/v1/circ/{room_id}/presence")

    async def circ_users(self, room_id: str) -> list[dict]:

        await self._rate_gate.wait_turn("circ_users", 50)
        return await self._request("GET", f"/v1/circ/{room_id}/users")

    async def circ_mark_read(self, room_id: str) -> dict:
        return await self._request("POST", f"/v1/circ/{room_id}/read")


    async def entries_list(self, limit: int = 20, cursor: str | None = None) -> dict:
        await self._rate_gate.wait_turn("entries_list", 38)
        params = {"limit": str(limit)}
        if cursor:
            params["cursor"] = cursor
        return await self._request("GET", "/v1/posts", params=params,
                                    return_full=True)

    async def entries_create(self, content: str, title: str | None = None,
                              topics: list[str] | None = None,
                              is_public: bool | None = None,
                              is_nsfw: bool | None = None) -> dict:
        body: dict = {"content": content}
        if title:
            body["title"] = title
        if topics:
            body["topics"] = topics
        if is_public is not None:
            body["isPublic"] = is_public
        if is_nsfw is not None:
            body["isNSFW"] = is_nsfw
        return await self._request("POST", "/v1/posts", json=body)

    async def entries_get(self, post_id: str) -> dict:
        return await self._request("GET", f"/v1/posts/{post_id}")

    async def replies_get(self, reply_id: str) -> dict:
        return await self._request("GET", f"/v1/replies/{reply_id}")

    async def replies_create(self, post_id: str, content: str,
                              parent_reply_id: str | None = None) -> dict:
        body: dict = {"postId": post_id, "content": content}
        if parent_reply_id:
            body["parentReplyId"] = parent_reply_id
        return await self._request("POST", "/v1/replies", json=body)

    async def replies_list(self, post_id: str, limit: int = 20,
                            cursor: str | None = None) -> dict:
        await self._rate_gate.wait_turn("replies_list", 38)
        params = {"limit": str(limit)}
        if cursor:
            params["cursor"] = cursor
        return await self._request("GET", f"/v1/posts/{post_id}/replies",
                                    params=params, return_full=True)


    async def cmail_list(self) -> list[dict]:
        await self._rate_gate.wait_turn("cmail_list", 25)
        return await self._request("GET", "/v1/cmail")

    async def cmail_start(self, recipient_username: str) -> dict:
        return await self._request("POST", "/v1/cmail",
                                    json={"recipientUsername": recipient_username})

    async def cmail_read(self, conversation_id: str, limit: int = 50,
                          before: int | None = None) -> dict:
        await self._rate_gate.wait_turn("cmail_read", 38)
        params = {"limit": str(limit)}
        if before is not None:
            params["before"] = str(before)
        return await self._request("GET", f"/v1/cmail/{conversation_id}",
                                    params=params, return_full=True)

    async def cmail_send(self, conversation_id: str, content: str) -> dict:
        try:
            result = await self._request("POST", f"/v1/cmail/{conversation_id}",
                                          json={"content": content})
        except CyberSpaceError as e:
            if e.status == 429:
                now = time.time()
                dq = self._cmail_send_times
                while len(dq) < self.CMAIL_SEND_DAILY_CAP:
                    dq.append(now)
            raise
        self._cmail_send_times.append(time.time())
        return result

    CMAIL_SEND_DAILY_CAP = 300
    CMAIL_SEND_WINDOW_SECONDS = 24 * 60 * 60

    def cmail_send_quota_estimate(self) -> dict:
        now = time.time()
        dq = self._cmail_send_times
        while dq and now - dq[0] > self.CMAIL_SEND_WINDOW_SECONDS:
            dq.popleft()
        used = len(dq)
        remaining = max(0, self.CMAIL_SEND_DAILY_CAP - used)
        seconds_until_next_slot = 0.0
        if used >= self.CMAIL_SEND_DAILY_CAP:
            seconds_until_next_slot = self.CMAIL_SEND_WINDOW_SECONDS - (now - dq[0])
        return {
            "used": used,
            "cap": self.CMAIL_SEND_DAILY_CAP,
            "remaining": remaining,
            "seconds_until_next_slot": max(0.0, seconds_until_next_slot),
        }

    async def cmail_mark_read(self, conversation_id: str) -> dict:
        await self._rate_gate.wait_turn("cmail_mark_read", 50)
        return await self._request("POST", f"/v1/cmail/{conversation_id}/read")

    async def cmail_typing_start(self, conversation_id: str) -> dict:
        await self._rate_gate.wait_turn(f"cmail_typing:{conversation_id}", 32)
        await self._rate_gate.wait_turn("cmail_typing:overall", 100)
        return await self._request("POST", f"/v1/cmail/{conversation_id}/typing")

    async def cmail_typing_stop(self, conversation_id: str) -> dict:
        await self._rate_gate.wait_turn(f"cmail_typing:{conversation_id}", 32)
        await self._rate_gate.wait_turn("cmail_typing:overall", 100)
        return await self._request("DELETE", f"/v1/cmail/{conversation_id}/typing")

    async def cmail_typing_status(self, conversation_id: str) -> dict:
        await self._rate_gate.wait_turn("cmail_typing_status", 50)
        return await self._request("GET", f"/v1/cmail/{conversation_id}/typing",
                                    return_full=True)


    async def users_get_profile(self, username: str) -> dict:
        await self._rate_gate.wait_turn("users_get_profile", 25)
        return await self._request("GET", f"/v1/users/{username}")

    async def users_poke(self, username: str) -> dict:
        try:
            result = await self._request("POST", f"/v1/users/{username}/poke")
        except CyberSpaceError as e:
            if e.status == 429:
                now = time.time()
                dq = self._poke_times
                while len(dq) < self.POKE_DAILY_CAP:
                    dq.append(now)
            raise
        self._poke_times.append(time.time())
        return result

    POKE_HOURLY_CAP = 1
    POKE_DAILY_CAP = 8
    POKE_HOUR_SECONDS = 60 * 60
    POKE_DAY_SECONDS = 24 * 60 * 60

    def poke_quota_estimate(self) -> dict:
        now = time.time()
        dq = self._poke_times
        while dq and now - dq[0] > self.POKE_DAY_SECONDS:
            dq.popleft()
        used_today = len(dq)
        used_hour = sum(1 for t in dq if now - t <= self.POKE_HOUR_SECONDS)
        remaining_today = max(0, self.POKE_DAILY_CAP - used_today)
        remaining_hour = max(0, self.POKE_HOURLY_CAP - used_hour)
        return {
            "used_today": used_today,
            "cap_today": self.POKE_DAILY_CAP,
            "remaining_today": remaining_today,
            "used_hour": used_hour,
            "cap_hour": self.POKE_HOURLY_CAP,
            "remaining_hour": remaining_hour,
        }


    async def users_get_posts(self, username: str, limit: int = 20,
                               cursor: str | None = None) -> dict:
        await self._rate_gate.wait_turn("entries_list", 38)
        params = {"limit": str(limit)}
        if cursor:
            params["cursor"] = cursor
        return await self._request("GET", f"/v1/users/{username}/posts",
                                    params=params, return_full=True)


    async def notifications_list(self, limit: int = 20, cursor: str | None = None,
                                  read: bool | None = None,
                                  types: list[str] | None = None) -> dict:
        await self._rate_gate.wait_turn("notifications_list", 25)
        params: dict = {"limit": str(limit)}
        if cursor:
            params["cursor"] = cursor
        if read is not None:
            params["read"] = "true" if read else "false"
        if types:
            params["type"] = ",".join(types)
        return await self._request("GET", "/v1/notifications", params=params,
                                    return_full=True)

    async def notifications_unread_count(self) -> int:
        await self._rate_gate.wait_turn("notifications_unread_count", 25)
        data = await self._request("GET", "/v1/notifications/unread-count")
        return (data or {}).get("count", 0)

    async def notifications_unread_preview(self, limit: int = 50) -> tuple[int, bool]:
        result = await self.notifications_list(limit=limit, read=False)
        items = result.get("data") or []
        return len(items), bool(result.get("cursor"))

    async def notifications_mark_read(self, notification_id: str) -> dict:
        return await self._request("PATCH", f"/v1/notifications/{notification_id}")

    async def notifications_mark_all_read(self) -> dict:
        return await self._request("POST", "/v1/notifications/read-all")


    async def _request(self, method: str, path: str, *, json=None,
                        params=None, auth: bool = True,
                        return_full: bool = False):
        headers = {}
        if auth:
            if not self.id_token:
                raise CyberSpaceError("UNAUTHORIZED", "Not logged in", 401)
            headers["Authorization"] = f"Bearer {self.id_token}"

        async with self.session.request(
            method, BASE_URL + path, json=json, params=params, headers=headers
        ) as resp:
            payload = await resp.json()
            if resp.status >= 400 or "error" in payload:
                err = payload.get("error", {})
                raise CyberSpaceError(
                    err.get("code", "UNKNOWN"),
                    err.get("message", "Request failed"),
                    resp.status,
                )
            if return_full:
                return payload
            return payload.get("data")
